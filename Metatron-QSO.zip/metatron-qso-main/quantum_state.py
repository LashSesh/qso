"""
Quantum State Operator - 13-Dimensional Hilbert Space on Metatron Cube

Phase 1: Migration from Rust (quantum_state.rs)

This module provides the foundational quantum state representation and unitary operators
for the 13-dimensional Hilbert space of the Metatron Cube.

Mathematical Foundation:
-----------------------
A quantum state is a 13-dimensional complex vector in Hilbert space:
    |ψ⟩ = Σᵢ αᵢ|i⟩,  i ∈ {1, 2, ..., 13}

Where:
    - αᵢ ∈ ℂ: Complex amplitude for node i
    - Σᵢ |αᵢ|² = 1: Normalization condition
    - |i⟩: Basis state (node i)
"""

import numpy as np
from typing import List, Optional, Tuple
from dataclasses import dataclass
import json


# Dimension of the Metatron Cube Hilbert space
METATRON_DIMENSION = 13


class QuantumState:
    """
    Quantum State on the 13-dimensional Hilbert space of the Metatron Cube.

    A quantum state is a normalized complex vector:
    |ψ⟩ = Σᵢ αᵢ|i⟩ with Σᵢ |αᵢ|² = 1

    Attributes:
        amplitudes: Complex amplitudes for the 13 nodes (numpy array of complex128)
    """

    def __init__(self, amplitudes: np.ndarray, normalize: bool = True):
        """
        Create a new Quantum State from complex amplitudes.

        Args:
            amplitudes: Array of up to 13 complex numbers
            normalize: If True, normalize the state to unit norm

        Raises:
            ValueError: If more than 13 amplitudes are provided
        """
        if len(amplitudes) > METATRON_DIMENSION:
            raise ValueError(
                f"QuantumState expects at most {METATRON_DIMENSION} amplitudes, "
                f"got {len(amplitudes)}"
            )

        # Pad with zeros if necessary
        if len(amplitudes) < METATRON_DIMENSION:
            amps = np.zeros(METATRON_DIMENSION, dtype=complex)
            amps[:len(amplitudes)] = amplitudes
        else:
            amps = np.array(amplitudes, dtype=complex)

        self.amplitudes = amps

        if normalize:
            self.normalize()

    @classmethod
    def basis_state(cls, node: int) -> 'QuantumState':
        """
        Create a basis state |i⟩.

        Args:
            node: Node index (0-based, 0-12)

        Returns:
            QuantumState representing |node⟩

        Raises:
            ValueError: If node index is out of range
        """
        if node < 0 or node >= METATRON_DIMENSION:
            raise ValueError(f"Node index must be in [0, {METATRON_DIMENSION-1}], got {node}")

        amps = np.zeros(METATRON_DIMENSION, dtype=complex)
        amps[node] = 1.0 + 0.0j

        return cls(amps, normalize=False)

    @classmethod
    def uniform_superposition(cls) -> 'QuantumState':
        """
        Create uniform superposition over all nodes.

        |ψ⟩ = (1/√13) Σᵢ |i⟩

        Returns:
            Uniformly distributed quantum state
        """
        amplitude = 1.0 / np.sqrt(METATRON_DIMENSION)
        amps = np.full(METATRON_DIMENSION, amplitude + 0.0j, dtype=complex)
        return cls(amps, normalize=False)

    @classmethod
    def random(cls, seed: Optional[int] = None) -> 'QuantumState':
        """
        Create a random quantum state (Haar measure approximation).

        Args:
            seed: Random seed for reproducibility

        Returns:
            Random normalized quantum state
        """
        if seed is not None:
            np.random.seed(seed)

        # Random complex amplitudes
        real_parts = np.random.randn(METATRON_DIMENSION)
        imag_parts = np.random.randn(METATRON_DIMENSION)
        amps = real_parts + 1j * imag_parts

        return cls(amps, normalize=True)

    def normalize(self) -> None:
        """
        Normalize the state to unit norm.

        After normalization: ⟨ψ|ψ⟩ = Σᵢ |αᵢ|² = 1
        """
        norm = self.norm()
        if norm == 0.0:
            # Null state -> set to |0⟩
            self.amplitudes = np.zeros(METATRON_DIMENSION, dtype=complex)
            self.amplitudes[0] = 1.0 + 0.0j
        else:
            self.amplitudes = self.amplitudes / norm

    def norm(self) -> float:
        """
        Calculate L2 norm of the state.

        ||ψ|| = √(Σᵢ |αᵢ|²)

        Returns:
            L2 norm (real number)
        """
        return np.sqrt(np.sum(np.abs(self.amplitudes)**2))

    def inner_product(self, other: 'QuantumState') -> complex:
        """
        Calculate inner product ⟨φ|ψ⟩.

        ⟨φ|ψ⟩ = Σᵢ φᵢ* ψᵢ

        Args:
            other: The other quantum state

        Returns:
            Complex inner product
        """
        return np.vdot(self.amplitudes, other.amplitudes)

    def apply(self, operator: 'QuantumUnitaryOperator') -> 'QuantumState':
        """
        Apply a quantum operator to this state.

        |ψ'⟩ = U|ψ⟩

        Args:
            operator: The unitary operator to apply

        Returns:
            New transformed state

        Raises:
            ValueError: If operator has wrong dimensions
        """
        if operator.matrix.shape != (METATRON_DIMENSION, METATRON_DIMENSION):
            raise ValueError(
                f"Operator must be {METATRON_DIMENSION}×{METATRON_DIMENSION} "
                f"to act on QuantumState, got shape {operator.matrix.shape}"
            )

        new_amplitudes = operator.matrix @ self.amplitudes
        return QuantumState(new_amplitudes, normalize=False)

    def probabilities(self) -> np.ndarray:
        """
        Calculate probability distribution |ψᵢ|².

        Returns:
            Array of 13 probabilities (sums to 1)
        """
        return np.abs(self.amplitudes)**2

    def measure(self) -> int:
        """
        Perform projective measurement in computational basis.

        Measures the state and collapses it to a basis state.
        Probability for node i is P(i) = |αᵢ|².

        Returns:
            Index of measured node (1-based: 1-13)

        Side Effects:
            Collapses the state to the measured basis state
        """
        probs = self.probabilities()

        # Sample from probability distribution
        measured_idx = np.random.choice(METATRON_DIMENSION, p=probs)

        # Collapse to basis state
        self.amplitudes = np.zeros(METATRON_DIMENSION, dtype=complex)
        self.amplitudes[measured_idx] = 1.0 + 0.0j

        return measured_idx + 1  # 1-based

    def expectation_value(self, observable: 'QuantumUnitaryOperator') -> complex:
        """
        Calculate expectation value of an observable.

        ⟨O⟩ = ⟨ψ|O|ψ⟩

        Args:
            observable: The observable operator

        Returns:
            Complex expectation value
        """
        o_psi = self.apply(observable)
        return self.inner_product(o_psi)

    def is_normalized(self, tolerance: float = 1e-10) -> bool:
        """
        Check if state is normalized.

        Args:
            tolerance: Numerical tolerance for normalization check

        Returns:
            True if ||ψ|| ≈ 1
        """
        return abs(self.norm() - 1.0) < tolerance

    def as_array(self) -> np.ndarray:
        """Get amplitudes as numpy array."""
        return self.amplitudes.copy()

    def __repr__(self) -> str:
        """String representation of the quantum state."""
        return f"QuantumState(dim={METATRON_DIMENSION}, norm={self.norm():.6f})"

    def to_dict(self) -> dict:
        """Serialize to dictionary."""
        return {
            'amplitudes_real': self.amplitudes.real.tolist(),
            'amplitudes_imag': self.amplitudes.imag.tolist(),
            'dimension': METATRON_DIMENSION
        }

    @classmethod
    def from_dict(cls, data: dict) -> 'QuantumState':
        """Deserialize from dictionary."""
        real = np.array(data['amplitudes_real'])
        imag = np.array(data['amplitudes_imag'])
        amps = real + 1j * imag
        return cls(amps, normalize=False)


class QuantumUnitaryOperator:
    """
    Quantum Unitary Operator - Linear operator on 13D Hilbert space.

    Represented as a 13×13 complex matrix.
    For unitary operators: U†U = UU† = I

    Attributes:
        matrix: 13×13 complex matrix (numpy array)
    """

    def __init__(self, matrix: np.ndarray):
        """
        Create a new quantum operator from a matrix.

        Args:
            matrix: 13×13 complex matrix

        Raises:
            ValueError: If matrix has wrong dimensions
        """
        if matrix.shape != (METATRON_DIMENSION, METATRON_DIMENSION):
            raise ValueError(
                f"QuantumUnitaryOperator matrix must be {METATRON_DIMENSION}×{METATRON_DIMENSION}, "
                f"got shape {matrix.shape}"
            )

        self.matrix = np.array(matrix, dtype=complex)

    @classmethod
    def identity(cls) -> 'QuantumUnitaryOperator':
        """Create identity operator."""
        return cls(np.eye(METATRON_DIMENSION, dtype=complex))

    @classmethod
    def from_permutation(cls, sigma: List[int]) -> 'QuantumUnitaryOperator':
        """
        Create permutation operator from a permutation.

        Args:
            sigma: Permutation of (1..=13), 1-based indexing

        Returns:
            Permutation operator

        Example:
            # Cyclic permutation: 1→2, 2→3, ..., 13→1
            perm = [2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 1]
            op = QuantumUnitaryOperator.from_permutation(perm)
        """
        p_matrix = cls._permutation_matrix(sigma)
        return cls(p_matrix.astype(complex))

    @staticmethod
    def _permutation_matrix(sigma: List[int]) -> np.ndarray:
        """
        Generate permutation matrix from permutation.

        Args:
            sigma: Permutation (1-based)

        Returns:
            Permutation matrix (real)
        """
        n = METATRON_DIMENSION
        p = np.zeros((n, n))

        for i in range(min(n, len(sigma))):
            s = sigma[i]
            if 1 <= s <= n:
                p[i, s - 1] = 1.0  # Convert from 1-based to 0-based

        return p

    def compose(self, other: 'QuantumUnitaryOperator') -> 'QuantumUnitaryOperator':
        """
        Compose two operators: C = A ∘ B.

        (A ∘ B)|ψ⟩ = A(B|ψ⟩)

        Args:
            other: The other operator

        Returns:
            Composed operator
        """
        result = self.matrix @ other.matrix
        return QuantumUnitaryOperator(result)

    def is_unitary(self, atol: float = 1e-8) -> bool:
        """
        Check if operator is unitary.

        U is unitary if U†U = UU† = I

        Args:
            atol: Absolute tolerance for comparison

        Returns:
            True if operator is unitary
        """
        # Calculate U†
        u_dagger = self.matrix.T.conj()

        # Calculate U†U and UU†
        product1 = u_dagger @ self.matrix
        product2 = self.matrix @ u_dagger

        # Identity matrix
        identity = np.eye(METATRON_DIMENSION, dtype=complex)

        # Check if close to identity
        close1 = np.allclose(product1, identity, atol=atol)
        close2 = np.allclose(product2, identity, atol=atol)

        return close1 and close2

    def adjoint(self) -> 'QuantumUnitaryOperator':
        """
        Calculate adjoint (Hermitian conjugate) U†.

        Returns:
            Adjoint operator
        """
        return QuantumUnitaryOperator(self.matrix.T.conj())

    def trace(self) -> complex:
        """
        Calculate trace Tr(U).

        Returns:
            Trace (complex number)
        """
        return np.trace(self.matrix)

    def eigendecomposition(self) -> Tuple[np.ndarray, np.ndarray]:
        """
        Compute eigendecomposition of the operator.

        Returns:
            (eigenvalues, eigenvectors) tuple
        """
        eigenvalues, eigenvectors = np.linalg.eig(self.matrix)
        return eigenvalues, eigenvectors

    def __repr__(self) -> str:
        """String representation."""
        is_unitary = "unitary" if self.is_unitary() else "non-unitary"
        return f"QuantumUnitaryOperator({METATRON_DIMENSION}×{METATRON_DIMENSION}, {is_unitary})"

    def __matmul__(self, other):
        """Matrix multiplication operator @."""
        if isinstance(other, QuantumUnitaryOperator):
            return self.compose(other)
        elif isinstance(other, QuantumState):
            return other.apply(self)
        else:
            raise TypeError(f"Cannot multiply QuantumUnitaryOperator with {type(other)}")


@dataclass
class QuantumStateParams:
    """Parameters for Quantum State operations."""
    normalize: bool = True


# Compatibility with existing interface
def create_basis_state(node: int) -> QuantumState:
    """Create basis state |node⟩ (0-based indexing)."""
    return QuantumState.basis_state(node)


def create_superposition(nodes: List[int], coefficients: Optional[List[complex]] = None) -> QuantumState:
    """
    Create superposition state over specified nodes.

    Args:
        nodes: List of node indices (0-based)
        coefficients: Optional coefficients (default: uniform)

    Returns:
        Superposition quantum state
    """
    amps = np.zeros(METATRON_DIMENSION, dtype=complex)

    if coefficients is None:
        # Uniform superposition
        coeff = 1.0 / np.sqrt(len(nodes))
        for node in nodes:
            amps[node] = coeff
    else:
        if len(coefficients) != len(nodes):
            raise ValueError("Number of coefficients must match number of nodes")
        for node, coeff in zip(nodes, coefficients):
            amps[node] = coeff

    return QuantumState(amps, normalize=True)
