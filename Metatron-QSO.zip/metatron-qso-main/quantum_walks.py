"""
Quantum Walk Module for Metatron Cube

This module implements Continuous-Time Quantum Walks (CTQW) and Discrete-Time
Quantum Walks (DTQW) on the Metatron Cube graph structure, with comprehensive
benchmarking metrics for mixing time, hitting time, and performance analysis.

References:
    - Aharonov et al. (2001): "Quantum Walks on Graphs"
    - Kempe (2003): "Quantum Random Walks"
    - Portugal (2013): "Quantum Walks and Search Algorithms"
"""

import numpy as np
from scipy.linalg import expm
from scipy.spatial.distance import jensenshannon
from typing import Optional, Tuple, Dict, List, Union
import time

from quantum_state import QuantumState
from metatron_graph import MetatronGraph


class QuantumWalk:
    """
    Abstract base class for Quantum Walks on graphs.

    Implements common functionality for both continuous-time and discrete-time
    quantum walks, including benchmark metrics and analysis tools.

    Attributes:
        graph: MetatronGraph instance representing the underlying graph structure
        state: Current quantum state of the walker
        hamiltonian: Hamiltonian operator (Laplacian-based or custom)
        num_nodes: Number of nodes in the graph (13 for Metatron Cube)
    """

    def __init__(
        self,
        graph: MetatronGraph,
        initial_state: Optional[QuantumState] = None,
        hamiltonian: Optional[np.ndarray] = None
    ):
        """
        Initialize quantum walk on a graph.

        Args:
            graph: MetatronGraph instance
            initial_state: Initial quantum state (default: uniform superposition)
            hamiltonian: Custom Hamiltonian (default: graph Laplacian)
        """
        self.graph = graph
        self.num_nodes = 13  # Metatron Cube has 13 nodes

        # Initialize Hamiltonian (default: -Laplacian for quantum walks)
        if hamiltonian is not None:
            self.hamiltonian = hamiltonian
        else:
            # Use negative Laplacian: H = -L = A - D
            self.hamiltonian = -self.graph.get_laplacian_matrix()

        # Initialize state
        if initial_state is not None:
            self.state = initial_state
        else:
            # Default: uniform superposition
            self.state = QuantumState.uniform_superposition()

        # Store initial state for resets (create new instance with copied amplitudes)
        self._initial_state = QuantumState(self.state.amplitudes.copy())

        # Cache for stationary distribution
        self._stationary_distribution = None

    def reset(self):
        """Reset quantum walk to initial state."""
        self.state = QuantumState(self._initial_state.amplitudes.copy())

    def get_probability_distribution(self) -> np.ndarray:
        """
        Get current probability distribution over nodes.

        Returns:
            Array of probabilities for each node (sums to 1)
        """
        return np.abs(self.state.amplitudes) ** 2

    def get_stationary_distribution(self) -> np.ndarray:
        """
        Compute the stationary (uniform) distribution for the graph.

        For a regular graph, this is uniform. For non-regular graphs,
        it's proportional to the degree.

        Returns:
            Stationary probability distribution
        """
        if self._stationary_distribution is None:
            # For Metatron Cube, compute based on degrees
            adjacency = self.graph.get_adjacency_matrix()
            degrees = np.sum(adjacency, axis=1)
            self._stationary_distribution = degrees / np.sum(degrees)
        return self._stationary_distribution

    def total_variation_distance(
        self,
        distribution: Optional[np.ndarray] = None
    ) -> float:
        """
        Compute total variation distance to stationary distribution.

        TV distance: δ(p, π) = 0.5 * Σ|p_i - π_i|

        Args:
            distribution: Target distribution (default: stationary)

        Returns:
            Total variation distance [0, 1]
        """
        current_dist = self.get_probability_distribution()

        if distribution is None:
            distribution = self.get_stationary_distribution()

        return 0.5 * np.sum(np.abs(current_dist - distribution))

    def kullback_leibler_divergence(
        self,
        distribution: Optional[np.ndarray] = None
    ) -> float:
        """
        Compute Kullback-Leibler divergence to target distribution.

        KL(p||π) = Σ p_i log(p_i / π_i)

        Args:
            distribution: Target distribution (default: stationary)

        Returns:
            KL divergence (always ≥ 0)
        """
        current_dist = self.get_probability_distribution()

        if distribution is None:
            distribution = self.get_stationary_distribution()

        # Avoid log(0) by adding small epsilon
        epsilon = 1e-15
        current_dist = current_dist + epsilon
        distribution = distribution + epsilon

        # Renormalize
        current_dist = current_dist / np.sum(current_dist)
        distribution = distribution / np.sum(distribution)

        return np.sum(current_dist * np.log(current_dist / distribution))

    def get_mixing_time(
        self,
        epsilon: float = 0.01,
        max_time: float = 100.0,
        dt: float = 0.1,
        verbose: bool = False
    ) -> Tuple[float, List[float]]:
        """
        Compute mixing time: minimum time until TV distance ≤ epsilon.

        Mixing time τ_mix(ε) is the first time t where δ(t) ≤ ε

        Args:
            epsilon: Convergence threshold (default: 0.01)
            max_time: Maximum time to search (default: 100.0)
            dt: Time step for sampling (default: 0.1)
            verbose: Print progress information

        Returns:
            Tuple of (mixing_time, tv_distances_over_time)
        """
        self.reset()

        times = np.arange(0, max_time, dt)
        tv_distances = []
        mixing_time = None

        for t in times:
            # Evolve to time t
            self.evolve(t, from_initial=True)

            # Compute TV distance
            tv_dist = self.total_variation_distance()
            tv_distances.append(tv_dist)

            if verbose and int(t) % 10 == 0:
                print(f"t={t:.1f}: TV distance = {tv_dist:.6f}")

            # Check convergence
            if mixing_time is None and tv_dist <= epsilon:
                mixing_time = t
                if verbose:
                    print(f"Mixing time found: τ_mix({epsilon}) = {mixing_time:.3f}")
                break

        if mixing_time is None:
            mixing_time = max_time
            if verbose:
                print(f"Warning: Did not converge within max_time={max_time}")

        return mixing_time, tv_distances

    def get_hitting_time(
        self,
        start_node: int,
        target_node: int,
        threshold: float = 0.5,
        max_time: float = 100.0,
        dt: float = 0.1
    ) -> float:
        """
        Compute quantum hitting time from start to target node.

        Hitting time: first time when probability at target exceeds threshold.

        Args:
            start_node: Starting node index [0-12]
            target_node: Target node index [0-12]
            threshold: Probability threshold (default: 0.5)
            max_time: Maximum time to search
            dt: Time step

        Returns:
            Hitting time (or max_time if not reached)
        """
        # Initialize at start node
        self.state = QuantumState.basis_state(start_node)

        times = np.arange(0, max_time, dt)

        for t in times:
            self.evolve(t, from_initial=True)
            prob_dist = self.get_probability_distribution()

            if prob_dist[target_node] >= threshold:
                return t

        return max_time

    def benchmark_all_pairs_hitting_time(
        self,
        threshold: float = 0.5,
        max_time: float = 50.0,
        dt: float = 0.1,
        verbose: bool = False
    ) -> Dict[str, float]:
        """
        Benchmark hitting times for all node pairs.

        Computes hitting time for all 13*12=156 start-target pairs.

        Args:
            threshold: Probability threshold
            max_time: Maximum time per pair
            dt: Time step
            verbose: Print progress

        Returns:
            Dictionary with statistics: mean, median, min, max, std
        """
        hitting_times = []

        total_pairs = self.num_nodes * (self.num_nodes - 1)
        current_pair = 0

        for start in range(self.num_nodes):
            for target in range(self.num_nodes):
                if start == target:
                    continue

                current_pair += 1
                if verbose and current_pair % 20 == 0:
                    print(f"Computing pair {current_pair}/{total_pairs}...")

                ht = self.get_hitting_time(start, target, threshold, max_time, dt)
                hitting_times.append(ht)

        hitting_times = np.array(hitting_times)

        return {
            'mean': np.mean(hitting_times),
            'median': np.median(hitting_times),
            'min': np.min(hitting_times),
            'max': np.max(hitting_times),
            'std': np.std(hitting_times),
            'all_times': hitting_times
        }

    def get_return_probability(self, start_node: int, time: float) -> float:
        """
        Compute return probability: probability of returning to start node.

        Args:
            start_node: Starting node index
            time: Time at which to evaluate

        Returns:
            Return probability [0, 1]
        """
        self.state = QuantumState.basis_state(start_node)
        self.evolve(time, from_initial=True)
        prob_dist = self.get_probability_distribution()
        return prob_dist[start_node]

    def evolve(self, time: float, from_initial: bool = False):
        """
        Evolve quantum state (to be implemented by subclasses).

        Args:
            time: Evolution time
            from_initial: If True, evolve from initial state; else from current
        """
        raise NotImplementedError("Subclasses must implement evolve()")


class ContinuousQuantumWalk(QuantumWalk):
    """
    Continuous-Time Quantum Walk (CTQW) implementation.

    Evolution via unitary operator: |ψ(t)⟩ = exp(-iHt) |ψ(0)⟩

    This is the standard CTQW where time evolution is governed by the
    Schrödinger equation with the graph Laplacian as Hamiltonian.
    """

    def __init__(
        self,
        graph: MetatronGraph,
        initial_state: Optional[QuantumState] = None,
        hamiltonian: Optional[np.ndarray] = None,
        hbar: float = 1.0
    ):
        """
        Initialize continuous-time quantum walk.

        Args:
            graph: MetatronGraph instance
            initial_state: Initial quantum state
            hamiltonian: Custom Hamiltonian (default: -Laplacian)
            hbar: Reduced Planck constant (default: 1.0, natural units)
        """
        super().__init__(graph, initial_state, hamiltonian)
        self.hbar = hbar

        # Precompute eigendecomposition for efficient evolution
        self._precompute_eigensystem()

    def _precompute_eigensystem(self):
        """Precompute eigenvalues and eigenvectors of Hamiltonian."""
        self.eigenvalues, self.eigenvectors = np.linalg.eigh(self.hamiltonian)

    def evolve(self, time: float, from_initial: bool = False):
        """
        Evolve quantum state via exp(-iHt/ℏ).

        Uses eigendecomposition for efficient computation:
        exp(-iHt/ℏ) = V exp(-iΛt/ℏ) V†

        Args:
            time: Evolution time
            from_initial: If True, evolve from initial state
        """
        if from_initial:
            state_amplitudes = self._initial_state.amplitudes
        else:
            state_amplitudes = self.state.amplitudes

        # Efficient evolution using eigendecomposition
        # |ψ(t)⟩ = Σ_k exp(-i λ_k t / ℏ) |k⟩⟨k|ψ(0)⟩
        coefficients = self.eigenvectors.T.conj() @ state_amplitudes
        evolved_coefficients = coefficients * np.exp(-1j * self.eigenvalues * time / self.hbar)
        evolved_amplitudes = self.eigenvectors @ evolved_coefficients

        self.state = QuantumState(evolved_amplitudes)

    def get_spectral_info(self) -> Dict[str, any]:
        """
        Get spectral information of the Hamiltonian.

        Returns:
            Dictionary with eigenvalues, gaps, and other spectral properties
        """
        eigenvalues_sorted = np.sort(self.eigenvalues)
        gaps = np.diff(eigenvalues_sorted)

        return {
            'eigenvalues': eigenvalues_sorted,
            'ground_state_energy': eigenvalues_sorted[0],
            'spectral_gap': gaps[0] if len(gaps) > 0 else 0.0,
            'spectral_gaps': gaps,
            'energy_range': eigenvalues_sorted[-1] - eigenvalues_sorted[0]
        }


class DiscreteQuantumWalk(QuantumWalk):
    """
    Discrete-Time Quantum Walk (DTQW) implementation.

    Evolution via coin operator and shift operator:
    |ψ(t+1)⟩ = S · (C ⊗ I) · |ψ(t)⟩

    Note: This is a simplified DTQW that uses a unitary step operator
    derived from the Hamiltonian, suitable for graph-based walks.
    """

    def __init__(
        self,
        graph: MetatronGraph,
        initial_state: Optional[QuantumState] = None,
        hamiltonian: Optional[np.ndarray] = None,
        dt: float = 0.1
    ):
        """
        Initialize discrete-time quantum walk.

        Args:
            graph: MetatronGraph instance
            initial_state: Initial quantum state
            hamiltonian: Custom Hamiltonian
            dt: Time step per discrete iteration (default: 0.1)
        """
        super().__init__(graph, initial_state, hamiltonian)
        self.dt = dt

        # Construct discrete step operator from Hamiltonian
        self._construct_step_operator()

    def _construct_step_operator(self):
        """
        Construct unitary step operator from Hamiltonian.

        Uses a small time-step approximation: U = exp(-iH·dt)
        """
        self.step_operator = expm(-1j * self.hamiltonian * self.dt)

    def evolve(self, time: float, from_initial: bool = False):
        """
        Evolve quantum state via discrete steps.

        Args:
            time: Total evolution time
            from_initial: If True, evolve from initial state
        """
        if from_initial:
            state_amplitudes = self._initial_state.amplitudes
        else:
            state_amplitudes = self.state.amplitudes

        # Compute number of steps
        num_steps = int(time / self.dt)

        # Apply step operator num_steps times
        evolved_amplitudes = state_amplitudes
        for _ in range(num_steps):
            evolved_amplitudes = self.step_operator @ evolved_amplitudes

        self.state = QuantumState(evolved_amplitudes)

    def evolve_steps(self, num_steps: int):
        """
        Evolve quantum state by a specific number of discrete steps.

        Args:
            num_steps: Number of discrete steps to take
        """
        for _ in range(num_steps):
            self.state.amplitudes = self.step_operator @ self.state.amplitudes


class ClassicalRandomWalk:
    """
    Classical random walk on graphs for comparison/baseline.

    Uses Monte Carlo simulation to estimate hitting times and mixing times.
    Provides a baseline for quantum speedup calculations.
    """

    def __init__(
        self,
        graph: MetatronGraph,
        initial_node: int = 0,
        seed: Optional[int] = None
    ):
        """
        Initialize classical random walk.

        Args:
            graph: MetatronGraph instance
            initial_node: Starting node
            seed: Random seed for reproducibility
        """
        self.graph = graph
        self.initial_node = initial_node
        self.current_node = initial_node
        self.num_nodes = 13

        if seed is not None:
            np.random.seed(seed)

        # Get transition matrix (row-stochastic)
        adjacency = graph.get_adjacency_matrix()
        degrees = np.sum(adjacency, axis=1, keepdims=True)
        self.transition_matrix = adjacency / degrees

    def reset(self):
        """Reset to initial node."""
        self.current_node = self.initial_node

    def step(self):
        """Take one random step to a neighbor."""
        neighbors = np.where(self.graph.get_adjacency_matrix()[self.current_node] > 0)[0]
        self.current_node = np.random.choice(neighbors)

    def get_hitting_time(
        self,
        start_node: int,
        target_node: int,
        max_steps: int = 10000,
        num_samples: int = 1000
    ) -> float:
        """
        Estimate classical hitting time via Monte Carlo.

        Args:
            start_node: Starting node
            target_node: Target node
            max_steps: Maximum steps per sample
            num_samples: Number of Monte Carlo samples

        Returns:
            Average hitting time
        """
        hitting_times = []

        for _ in range(num_samples):
            self.current_node = start_node
            steps = 0

            while steps < max_steps:
                if self.current_node == target_node:
                    hitting_times.append(steps)
                    break
                self.step()
                steps += 1

            if steps == max_steps:
                hitting_times.append(max_steps)

        return np.mean(hitting_times)

    def get_mixing_time(
        self,
        epsilon: float = 0.01,
        max_steps: int = 1000,
        num_samples: int = 5000
    ) -> Tuple[int, List[float]]:
        """
        Estimate classical mixing time via Monte Carlo.

        Args:
            epsilon: Convergence threshold
            max_steps: Maximum steps
            num_samples: Number of samples for distribution estimation

        Returns:
            Tuple of (mixing_time, tv_distances)
        """
        # Compute stationary distribution (uniform for regular graphs)
        degrees = np.sum(self.graph.get_adjacency_matrix(), axis=1)
        stationary = degrees / np.sum(degrees)

        tv_distances = []
        mixing_time = None

        for t in range(max_steps):
            # Estimate distribution at time t via sampling
            distribution = np.zeros(self.num_nodes)

            for _ in range(num_samples):
                self.reset()
                for _ in range(t):
                    self.step()
                distribution[self.current_node] += 1

            distribution = distribution / num_samples

            # Compute TV distance
            tv_dist = 0.5 * np.sum(np.abs(distribution - stationary))
            tv_distances.append(tv_dist)

            if mixing_time is None and tv_dist <= epsilon:
                mixing_time = t
                break

        if mixing_time is None:
            mixing_time = max_steps

        return mixing_time, tv_distances


def compare_quantum_classical(
    graph: MetatronGraph,
    verbose: bool = True
) -> Dict[str, any]:
    """
    Comprehensive comparison between quantum and classical walks.

    Args:
        graph: MetatronGraph instance
        verbose: Print detailed results

    Returns:
        Dictionary with comparison metrics and speedup factors
    """
    if verbose:
        print("=" * 70)
        print("QUANTUM vs CLASSICAL WALK COMPARISON - METATRON CUBE")
        print("=" * 70)

    # Initialize walks
    ctqw = ContinuousQuantumWalk(graph)
    classical = ClassicalRandomWalk(graph, seed=42)

    # 1. Mixing Time Comparison
    if verbose:
        print("\n[1] MIXING TIME ANALYSIS")
        print("-" * 70)

    start_time = time.time()
    quantum_mixing_time, _ = ctqw.get_mixing_time(epsilon=0.01, verbose=False)
    quantum_time_elapsed = time.time() - start_time

    start_time = time.time()
    classical_mixing_time, _ = classical.get_mixing_time(epsilon=0.01, num_samples=5000)
    classical_time_elapsed = time.time() - start_time

    mixing_speedup = classical_mixing_time / quantum_mixing_time
    computational_speedup = classical_time_elapsed / quantum_time_elapsed

    if verbose:
        print(f"Quantum Mixing Time:    τ_mix = {quantum_mixing_time:.3f} (computed in {quantum_time_elapsed:.4f}s)")
        print(f"Classical Mixing Time:  τ_mix = {classical_mixing_time:.1f} steps (computed in {classical_time_elapsed:.4f}s)")
        print(f"Speedup Factor:         {mixing_speedup:.2f}x")
        print(f"Computational Speedup:  {computational_speedup:.2f}x")

    # 2. Hitting Time Comparison (sample pairs)
    if verbose:
        print("\n[2] HITTING TIME ANALYSIS (sample pairs)")
        print("-" * 70)

    sample_pairs = [(0, 6), (1, 7), (0, 12), (5, 10)]  # Representative pairs

    quantum_hitting_times = []
    classical_hitting_times = []

    for start, target in sample_pairs:
        qht = ctqw.get_hitting_time(start, target, threshold=0.5)
        cht = classical.get_hitting_time(start, target, num_samples=1000)

        quantum_hitting_times.append(qht)
        classical_hitting_times.append(cht)

        if verbose:
            speedup = cht / qht
            print(f"Pair ({start} → {target}): Quantum={qht:.2f}, Classical={cht:.1f}, Speedup={speedup:.2f}x")

    avg_quantum_ht = np.mean(quantum_hitting_times)
    avg_classical_ht = np.mean(classical_hitting_times)
    avg_hitting_speedup = avg_classical_ht / avg_quantum_ht

    if verbose:
        print(f"\nAverage Hitting Time Speedup: {avg_hitting_speedup:.2f}x")

    # 3. Return Probability
    if verbose:
        print("\n[3] RETURN PROBABILITY @ t=10")
        print("-" * 70)

    quantum_return_prob = ctqw.get_return_probability(0, time=10.0)

    # Estimate classical return probability
    classical_returns = 0
    num_samples = 5000
    for _ in range(num_samples):
        classical.current_node = 0
        for _ in range(100):  # Approximate t=10 with 100 steps
            classical.step()
        if classical.current_node == 0:
            classical_returns += 1
    classical_return_prob = classical_returns / num_samples

    if verbose:
        print(f"Quantum Return Probability:   {quantum_return_prob:.4f}")
        print(f"Classical Return Probability: {classical_return_prob:.4f}")

    # Summary
    if verbose:
        print("\n" + "=" * 70)
        print("SUMMARY")
        print("=" * 70)
        print(f"Overall Quantum Advantage:  {mixing_speedup:.2f}x faster mixing")
        print(f"Average Hitting Speedup:    {avg_hitting_speedup:.2f}x")
        print(f"Computational Efficiency:   {computational_speedup:.2f}x faster computation")
        print("=" * 70)

    return {
        'quantum_mixing_time': quantum_mixing_time,
        'classical_mixing_time': classical_mixing_time,
        'mixing_speedup': mixing_speedup,
        'quantum_hitting_times': quantum_hitting_times,
        'classical_hitting_times': classical_hitting_times,
        'avg_hitting_speedup': avg_hitting_speedup,
        'quantum_return_prob': quantum_return_prob,
        'classical_return_prob': classical_return_prob,
        'computational_speedup': computational_speedup
    }
