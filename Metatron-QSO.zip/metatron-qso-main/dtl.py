"""
Dynamic Tripolar Logic (DTL) - Axiomatische Fundierung

Implements the complete Dynamic Tripolar Logic framework as specified in QSO.pdf Section 2.

The DTL extends classical binary logic with a third, dynamic state class that encompasses
time-dependent, oscillatory trajectories. This provides:
- Information-theoretic advantage: 58.5% capacity increase over binary systems
- Functional completeness: Binary logic fully embedded
- Attractor-based semantics: Robust interpretation via topological properties

State Space:
-----------
Σ = {L0, L1} ∪ LD

Where:
- L0 = 0 ∈ ℝ: Stable null-pole (logical: false, physical: ground state)
- L1 = 1 ∈ ℝ: Stable one-pole (logical: true, physical: excited state)
- LD: Class of dynamic tripolar states (time-dependent trajectories)
"""

import numpy as np
from typing import Callable, Union, List, Tuple, Optional
from dataclasses import dataclass
from enum import Enum
import matplotlib.pyplot as plt


class TripolarState(Enum):
    """Enumeration of tripolar state classes."""
    L0 = "L0"  # Stable null-pole
    L1 = "L1"  # Stable one-pole
    LD = "LD"  # Dynamic state


@dataclass
class DTLState:
    """
    Dynamic Tripolar Logic State.

    A DTL state can be:
    - Static: L0 (value=0.0) or L1 (value=1.0)
    - Dynamic: LD (time-dependent function x: ℝ → [0,1])
    """
    state_type: TripolarState
    value: Optional[float] = None
    trajectory: Optional[Callable[[float], float]] = None

    def __post_init__(self):
        """Validate state consistency."""
        if self.state_type == TripolarState.L0:
            self.value = 0.0
        elif self.state_type == TripolarState.L1:
            self.value = 1.0
        elif self.state_type == TripolarState.LD:
            if self.trajectory is None:
                raise ValueError("LD state requires a trajectory function")

    def evaluate(self, t: float) -> float:
        """
        Evaluate the state at time t.

        Args:
            t: Time point

        Returns:
            State value in [0, 1]
        """
        if self.state_type in [TripolarState.L0, TripolarState.L1]:
            return self.value
        else:
            return self.trajectory(t)

    @classmethod
    def L0(cls) -> 'DTLState':
        """Create L0 (null-pole) state."""
        return cls(TripolarState.L0, value=0.0)

    @classmethod
    def L1(cls) -> 'DTLState':
        """Create L1 (one-pole) state."""
        return cls(TripolarState.L1, value=1.0)

    @classmethod
    def LD_oscillatory(cls, frequency: float, phase: float = 0.0, amplitude: float = 0.5, offset: float = 0.5) -> 'DTLState':
        """
        Create oscillatory LD state.

        x(t) = offset + amplitude * sin(2π * frequency * t + phase)

        Args:
            frequency: Oscillation frequency
            phase: Phase offset
            amplitude: Oscillation amplitude
            offset: Center value

        Returns:
            Oscillatory LD state
        """
        def trajectory(t: float) -> float:
            value = offset + amplitude * np.sin(2 * np.pi * frequency * t + phase)
            return np.clip(value, 0.0, 1.0)

        return cls(TripolarState.LD, trajectory=trajectory)

    @classmethod
    def LD_from_phase(cls, phase_trajectory: Callable[[float], float]) -> 'DTLState':
        """
        Create LD state from phase trajectory φ: ℝ → S¹.

        Maps phase to [0,1] via: x(t) = (1 + cos(φ(t))) / 2

        Args:
            phase_trajectory: Function returning phase in radians

        Returns:
            LD state derived from phase
        """
        def trajectory(t: float) -> float:
            phi = phase_trajectory(t)
            return (1.0 + np.cos(phi)) / 2.0

        return cls(TripolarState.LD, trajectory=trajectory)


class DTLOperations:
    """
    DTL Operations: ∧_DTL, ∨_DTL, ¬_DTL

    These operations extend boolean logic to time-dependent trajectories.
    For static states (L0, L1), they reduce to standard boolean operations.
    """

    @staticmethod
    def AND(x: DTLState, y: DTLState) -> DTLState:
        """
        DTL AND operation: x ∧_DTL y

        For trajectories: (x ∧_DTL y)(t) = min{x(t), y(t)}
        """
        if x.state_type in [TripolarState.L0, TripolarState.L1] and y.state_type in [TripolarState.L0, TripolarState.L1]:
            # Pure boolean case
            result_value = min(x.value, y.value)
            return DTLState.L0() if result_value == 0.0 else DTLState.L1()
        else:
            # Dynamic case
            def trajectory(t: float) -> float:
                return min(x.evaluate(t), y.evaluate(t))

            return DTLState(TripolarState.LD, trajectory=trajectory)

    @staticmethod
    def OR(x: DTLState, y: DTLState) -> DTLState:
        """
        DTL OR operation: x ∨_DTL y

        For trajectories: (x ∨_DTL y)(t) = max{x(t), y(t)}
        """
        if x.state_type in [TripolarState.L0, TripolarState.L1] and y.state_type in [TripolarState.L0, TripolarState.L1]:
            # Pure boolean case
            result_value = max(x.value, y.value)
            return DTLState.L0() if result_value == 0.0 else DTLState.L1()
        else:
            # Dynamic case
            def trajectory(t: float) -> float:
                return max(x.evaluate(t), y.evaluate(t))

            return DTLState(TripolarState.LD, trajectory=trajectory)

    @staticmethod
    def NOT(x: DTLState) -> DTLState:
        """
        DTL NOT operation: ¬_DTL x

        For trajectories: (¬_DTL x)(t) = 1 - x(t)
        """
        if x.state_type in [TripolarState.L0, TripolarState.L1]:
            # Pure boolean case
            return DTLState.L1() if x.value == 0.0 else DTLState.L0()
        else:
            # Dynamic case
            def trajectory(t: float) -> float:
                return 1.0 - x.evaluate(t)

            return DTLState(TripolarState.LD, trajectory=trajectory)


class DTLResonator:
    """
    DTL Resonator - Phase-based dynamical system on S¹.

    The resonator is the fundamental dynamic element of DTL, implementing
    a Kuramoto-like oscillator with multiple inputs.

    Dynamics:
    --------
    dφ/dt = ω + Σᵢ κᵢIᵢ(t) sin(θᵢ - φ)

    Where:
    - φ ∈ S¹: Phase state
    - ω ∈ ℝ: Intrinsic frequency
    - Iᵢ(t): Input signals
    - θᵢ ∈ S¹: Target phases of inputs
    - κᵢ > 0: Coupling strengths

    Stable attractors φ₀, φ₁ correspond to logical states L0, L1.
    Oscillatory trajectories correspond to LD.
    """

    def __init__(self, omega: float, initial_phase: float = 0.0):
        """
        Initialize DTL Resonator.

        Args:
            omega: Intrinsic frequency
            initial_phase: Initial phase (radians)
        """
        self.omega = omega
        self.phase = initial_phase
        self.inputs: List[Tuple[float, float, Callable[[float], float]]] = []  # (theta, kappa, I(t))

    def add_input(self, theta: float, kappa: float, input_signal: Callable[[float], float]):
        """
        Add input to the resonator.

        Args:
            theta: Target phase (radians)
            kappa: Coupling strength (> 0)
            input_signal: Time-dependent input function I(t)
        """
        self.inputs.append((theta, kappa, input_signal))

    def derivative(self, phi: float, t: float) -> float:
        """
        Calculate dφ/dt at given phase and time.

        Args:
            phi: Current phase
            t: Current time

        Returns:
            Phase derivative
        """
        dphi = self.omega

        for theta, kappa, input_signal in self.inputs:
            I_t = input_signal(t)
            dphi += kappa * I_t * np.sin(theta - phi)

        return dphi

    def integrate(self, t_span: Tuple[float, float], dt: float = 0.01) -> Tuple[np.ndarray, np.ndarray]:
        """
        Integrate the resonator dynamics using Euler method.

        Args:
            t_span: (t_start, t_end)
            dt: Time step

        Returns:
            (times, phases) arrays
        """
        t_start, t_end = t_span
        times = np.arange(t_start, t_end, dt)
        phases = np.zeros_like(times)
        phases[0] = self.phase

        for i in range(1, len(times)):
            t = times[i-1]
            phi = phases[i-1]
            dphi = self.derivative(phi, t)
            phases[i] = phi + dphi * dt

        return times, phases

    def get_logical_state(self, tolerance: float = 0.1) -> TripolarState:
        """
        Determine logical state based on current phase.

        Args:
            tolerance: Tolerance for fixed point detection

        Returns:
            Inferred tripolar state
        """
        # Map phase to [0, 1]
        x = (1.0 + np.cos(self.phase)) / 2.0

        if abs(x - 0.0) < tolerance:
            return TripolarState.L0
        elif abs(x - 1.0) < tolerance:
            return TripolarState.L1
        else:
            return TripolarState.LD

    def to_dtl_state(self, t_span: Tuple[float, float], dt: float = 0.01) -> DTLState:
        """
        Convert resonator dynamics to DTL state.

        Args:
            t_span: Time span for integration
            dt: Time step

        Returns:
            DTL state representing the resonator trajectory
        """
        times, phases = self.integrate(t_span, dt)

        # Create interpolated trajectory
        def trajectory(t: float) -> float:
            # Linear interpolation
            if t < times[0]:
                phi = phases[0]
            elif t >= times[-1]:
                phi = phases[-1]
            else:
                idx = np.searchsorted(times, t)
                if idx == 0:
                    phi = phases[0]
                else:
                    t0, t1 = times[idx-1], times[idx]
                    phi0, phi1 = phases[idx-1], phases[idx]
                    phi = phi0 + (phi1 - phi0) * (t - t0) / (t1 - t0)

            # Map phase to [0, 1]
            return (1.0 + np.cos(phi)) / 2.0

        return DTLState(TripolarState.LD, trajectory=trajectory)


class TripolarInformationTheory:
    """
    Information-theoretic properties of DTL.

    Theorem 2.7 (QSO.pdf): Tripolar channel capacity
    C_tri = log₂(3) ≈ 1.585 Bit/Symbol
    Advantage over binary: 58.5%
    """

    @staticmethod
    def channel_capacity_tripolar() -> float:
        """
        Calculate tripolar channel capacity.

        Returns:
            Capacity in bits/symbol
        """
        return np.log2(3)

    @staticmethod
    def channel_capacity_binary() -> float:
        """
        Calculate binary channel capacity.

        Returns:
            Capacity in bits/symbol
        """
        return 1.0

    @staticmethod
    def relative_advantage() -> float:
        """
        Calculate relative capacity advantage of tripolar over binary.

        Returns:
            Relative advantage (fraction)
        """
        c_tri = TripolarInformationTheory.channel_capacity_tripolar()
        c_bin = TripolarInformationTheory.channel_capacity_binary()
        return (c_tri - c_bin) / c_bin

    @staticmethod
    def entropy(probabilities: np.ndarray) -> float:
        """
        Calculate Shannon entropy.

        H = -Σᵢ pᵢ log₂(pᵢ)

        Args:
            probabilities: Probability distribution

        Returns:
            Entropy in bits
        """
        # Filter out zero probabilities
        p = probabilities[probabilities > 0]
        return -np.sum(p * np.log2(p))

    @staticmethod
    def print_capacity_analysis():
        """Print detailed capacity analysis."""
        c_tri = TripolarInformationTheory.channel_capacity_tripolar()
        c_bin = TripolarInformationTheory.channel_capacity_binary()
        advantage = TripolarInformationTheory.relative_advantage()

        print("=" * 60)
        print("TRIPOLAR INFORMATION CAPACITY ANALYSIS")
        print("=" * 60)
        print(f"Binary channel capacity:    C_bin = {c_bin:.6f} Bit/Symbol")
        print(f"Tripolar channel capacity:  C_tri = {c_tri:.6f} Bit/Symbol")
        print(f"Absolute advantage:         ΔC = {c_tri - c_bin:.6f} Bit/Symbol")
        print(f"Relative advantage:         {advantage*100:.2f}%")
        print("=" * 60)
        print(f"\nFor 13-node Metatron system:")
        print(f"  Binary capacity:   {13 * c_bin:.2f} Bits")
        print(f"  Tripolar capacity: {13 * c_tri:.2f} Bits")
        print(f"  Capacity gain:     {13 * (c_tri - c_bin):.2f} Bits ({advantage*100:.1f}%)")
        print("=" * 60)


def visualize_dtl_states(states: List[DTLState], labels: List[str], t_span: Tuple[float, float] = (0, 10), dt: float = 0.01):
    """
    Visualize DTL states over time.

    Args:
        states: List of DTL states to plot
        labels: Labels for each state
        t_span: Time span
        dt: Time step
    """
    times = np.arange(t_span[0], t_span[1], dt)

    plt.figure(figsize=(12, 6))

    for state, label in zip(states, labels):
        values = [state.evaluate(t) for t in times]
        plt.plot(times, values, label=label, linewidth=2)

    plt.xlabel('Time t', fontsize=12)
    plt.ylabel('State Value x(t)', fontsize=12)
    plt.title('Dynamic Tripolar Logic States', fontsize=14, fontweight='bold')
    plt.legend(fontsize=10)
    plt.grid(True, alpha=0.3)
    plt.ylim(-0.1, 1.1)

    plt.tight_layout()
    return plt.gcf()


# Demonstration and validation
if __name__ == "__main__":
    print("\n" + "=" * 70)
    print("DYNAMIC TRIPOLAR LOGIC (DTL) - DEMONSTRATION")
    print("=" * 70 + "\n")

    # Information capacity analysis
    TripolarInformationTheory.print_capacity_analysis()

    # Create example states
    L0 = DTLState.L0()
    L1 = DTLState.L1()
    LD_osc = DTLState.LD_oscillatory(frequency=0.5, phase=0, amplitude=0.4, offset=0.5)

    print("\n" + "-" * 70)
    print("DTL STATE EXAMPLES")
    print("-" * 70)
    print(f"L0 state at t=5: {L0.evaluate(5)}")
    print(f"L1 state at t=5: {L1.evaluate(5)}")
    print(f"LD oscillatory at t=5: {LD_osc.evaluate(5):.6f}")

    # Test operations
    print("\n" + "-" * 70)
    print("DTL OPERATIONS (Functional Completeness)")
    print("-" * 70)
    print(f"L0 ∧ L0 = {DTLOperations.AND(L0, L0).value}")
    print(f"L0 ∧ L1 = {DTLOperations.AND(L0, L1).value}")
    print(f"L1 ∧ L1 = {DTLOperations.AND(L1, L1).value}")
    print(f"¬L0 = {DTLOperations.NOT(L0).value}")
    print(f"¬L1 = {DTLOperations.NOT(L1).value}")

    # DTL Resonator
    print("\n" + "-" * 70)
    print("DTL RESONATOR")
    print("-" * 70)
    resonator = DTLResonator(omega=0.1, initial_phase=0.0)
    resonator.add_input(theta=0.0, kappa=1.0, input_signal=lambda t: 1.0)
    resonator.add_input(theta=np.pi, kappa=0.5, input_signal=lambda t: 0.5 * np.sin(2*np.pi*0.3*t))

    times, phases = resonator.integrate((0, 20), dt=0.01)
    print(f"Resonator integrated over {len(times)} time steps")
    print(f"Final phase: {phases[-1]:.6f} rad")
    print(f"Logical state: {resonator.get_logical_state()}")

    print("\n" + "=" * 70)
    print("DTL FRAMEWORK INITIALIZED SUCCESSFULLY")
    print("=" * 70 + "\n")
