# Metatron Quantum State Operator (QSO)

**A complete Python implementation of the tripolar Quantum State Operator based on the Metatron Cube**

## Overview

This project implements a complete Quantum State Operator (QSO) for the Metatron Cube, a sacred geometry with 13 nodes and 78 edges that contains all five Platonic solids. The implementation is based on Dynamic Tripolar Logic (DTL) and provides:

- **58.5% information advantage** over binary systems
- **13-dimensional Hilbert space** (H₁₃) for quantum states
- **Graph Laplace operator** for spectral analysis
- **Metatron Hamilton operator** for quantum dynamics
- **DTL resonator network** (Kuramoto model) for synchronization
- **Symmetry group G_M** with hexagonal and cubic symmetries

## Project Phases

### ✅ Phase 1: Migration (Rust → Python)

The Rust implementation from `quantum_state.rs` was completely and idiomatically transferred to Python:

- `QuantumState`: 13-dimensional quantum states with complex amplitudes
- `QuantumUnitaryOperator`: Unitary operators on H₁₃
- Normalization, inner product, measurement, time evolution

### ✅ Phase 2: Complete QSO (based on QSO.pdf)

Implementation of all components from the scientific paper:

- **DTL Framework** (`dtl.py`): Tripolar logic with L0, L1, LD states
- **Metatron Graph** (`metatron_graph.py`): Precise graph structure with 13 nodes, 78 edges
- **QSO** (`qso.py`): Complete Quantum State Operator with:
  - Graph Laplacian
  - Hamilton operator
  - Symmetry group
  - Spectral analysis
  - DTL resonator network

## Installation

```bash
# Clone the repository
cd metatron-qso

# Install dependencies
pip install numpy scipy matplotlib networkx
```

### Dependencies

- Python 3.8+
- NumPy >= 1.20
- SciPy >= 1.7
- Matplotlib >= 3.3 (for visualization)
- NetworkX >= 2.5 (for graph analysis)

## Quick Start

```python
from qso import QuantumStateOperator

# Create QSO with default parameters
qso = QuantumStateOperator()

# Analyze complete system
qso.print_full_analysis()

# Create quantum state
initial_state = qso.get_basis_state(0)  # Initial state at center node

# Time evolution
evolved_state = qso.evolve_quantum_state(initial_state, time=1.0)

# Quantum state → DTL correspondence
dtl_values = qso.quantum_to_dtl_correspondence(evolved_state)
print(f"DTL values: {dtl_values}")
```

## Modules

### 1. `quantum_state.py` - Quantum States (Phase 1)

Migration of the Rust code with full functionality:

```python
from quantum_state import QuantumState, QuantumUnitaryOperator

# Basis state
state = QuantumState.basis_state(0)  # |0⟩

# Superposition
superposition = QuantumState.uniform_superposition()

# Random state (Haar measure)
random_state = QuantumState.random(seed=42)

# Apply operator
permutation = list(range(1, 13)) + [0]  # Cyclic
operator = QuantumUnitaryOperator.from_permutation(permutation)
new_state = state.apply(operator)
```

### 2. `dtl.py` - Dynamic Tripolar Logic

```python
from dtl import DTLState, DTLOperations, TripolarInformationTheory

# Static states
L0 = DTLState.L0()  # Null pole
L1 = DTLState.L1()  # One pole

# Dynamic state (oscillatory)
LD = DTLState.LD_oscillatory(frequency=0.5, amplitude=0.4)

# Logical operations
result = DTLOperations.AND(L0, L1)  # ∧_DTL
result = DTLOperations.OR(L0, L1)   # ∨_DTL
result = DTLOperations.NOT(L0)      # ¬_DTL

# Information capacity
capacity = TripolarInformationTheory.channel_capacity_tripolar()
print(f"Tripolar capacity: {capacity:.3f} Bits/Symbol")  # 1.585
```

### 3. `metatron_graph.py` - Graph Structure

```python
from metatron_graph import MetatronGraph

# Initialize Metatron Cube graph
graph = MetatronGraph()

# Adjacency matrix
A = graph.get_adjacency_matrix()  # 13×13

# Graph Laplacian
L = graph.get_laplacian_matrix()  # D - A

# Statistics
stats = graph.get_statistics()
print(f"Nodes: {stats['num_nodes']}")  # 13
print(f"Edges: {stats['num_edges']}")  # 78

# 3D visualization
graph.visualize_3d(show_labels=True)
```

### 4. `qso.py` - Complete Quantum State Operator

```python
from qso import QuantumStateOperator, QSOParameters

# Create QSO with custom parameters
params = QSOParameters(
    J=1.0,                              # Coupling constant
    epsilon=np.zeros(13),               # On-site energies
    kappa=2.0                           # Resonator coupling
)
qso = QuantumStateOperator(params)

# Hamiltonian spectrum
spectrum_info = qso.hamiltonian.get_spectrum_info()
print(f"Ground state energy: {spectrum_info['ground_state_energy']}")

# Simulate resonator network
times, phases = qso.simulate_resonator_dynamics((0, 20), dt=0.01)

# Synchronization parameter
order_param = qso.resonator_network.compute_order_parameter(phases)
```

## Examples

Complete examples in `examples.py`:

```bash
python examples.py
```

The examples demonstrate:

1. **Basic quantum operations**: States, operators, inner products
2. **DTL states**: Static and dynamic, logical operations
3. **Metatron graph analysis**: Spectrum, connectivity, Laplacian
4. **Hamiltonian dynamics**: Time evolution, spectral analysis
5. **Resonator network**: Synchronization, Kuramoto model
6. **Quantum-DTL correspondence**: Amplitudes → probabilities, phases
7. **Symmetry operations**: Group action on states

## Mathematical Foundations

### 13-Dimensional Hilbert Space

A quantum state is a normalized complex vector:

```
|ψ⟩ = Σᵢ αᵢ|i⟩,  i ∈ {1, 2, ..., 13}
Σᵢ |αᵢ|² = 1
```

### Metatron Hamilton Operator

```
Ĥ_MC = -J·L̂ + Σᵢ εᵢ|vᵢ⟩⟨vᵢ|
```

- **L̂**: Graph Laplacian (D - A)
- **J**: Hopping constant
- **εᵢ**: On-site energies

### DTL Resonator Network

Kuramoto model on the Metatron graph:

```
dφᵢ/dt = ωᵢ + Σⱼ κᵢⱼ sin(φⱼ - φᵢ)
```

- **φᵢ**: Phase of the resonator at node i
- **ωᵢ**: Intrinsic frequency
- **κᵢⱼ**: Coupling strength

## Information-Theoretic Advantage

### Tripolar vs. Binary Systems

| Property | Binary | Tripolar | Advantage |
|----------|--------|----------|-----------|
| Capacity/Symbol | 1.000 Bit | 1.585 Bit | **+58.5%** |
| Metatron System (13 Nodes) | 13 Bit | 20.6 Bit | **+7.6 Bit** |
| With Phase Encoding | 13 Bit | 46.6 Bit | **+258%** |

## Visualization

### Metatron Cube in 3D

```python
from metatron_graph import MetatronGraph

graph = MetatronGraph()
fig = graph.visualize_3d(show_labels=True, save_path='metatron_cube.png')
```

### DTL States Over Time

```python
from dtl import visualize_dtl_states, DTLState

states = [
    DTLState.L0(),
    DTLState.L1(),
    DTLState.LD_oscillatory(frequency=0.5)
]
labels = ['L0', 'L1', 'LD']
fig = visualize_dtl_states(states, labels, t_span=(0, 10))
```

## Tests

Comprehensive tests for all modules:

```bash
python test_qso.py
```

Tests include:
- Quantum state normalization
- Operator unitarity
- Graph connectivity
- Hamiltonian spectrum
- DTL operations
- Resonator synchronization

## Architecture

```
metatron-qso/
├── quantum_state.py      # Phase 1: Rust → Python Migration
├── dtl.py                # Dynamic Tripolar Logic
├── metatron_graph.py     # Graph structure (13 nodes, 78 edges)
├── qso.py                # Complete Quantum State Operator
├── examples.py           # Comprehensive examples
├── test_qso.py           # Unit tests
├── README.md             # English documentation (this file)
├── README_de.md          # German documentation
└── QSO.pdf               # Scientific paper (specification)
```

## Applications

### 1. Quantum Information Processing

- Quantum walks on Metatron graph
- Graph-based quantum algorithms
- Topological quantum codes

### 2. Cognitive Architectures

- Post-symbolic cognition
- Tripolar decision systems
- Uncertainty modeling

### 3. Structure-Based Cryptography

- Graph-based public-key systems
- Physical Unclonable Functions (PUFs)
- Chaotic DTL trajectories as random sources

### 4. Hardware Implementation

- **Silicon Photonics**: Phase-based DTL resonators
- **Neuromorphic Systems**: Spiking neural networks with tripolar encoding
- **Quantum Computers**: Native implementation on 13-qubit systems

## Scientific Foundation

This implementation is fully based on:

**"The Metatron Cube as a Tripolar Quantum State Operator:
A Fully Defined DTL-Based Quantum Model"**
Sebastian Klemm, November 11, 2025 (QSO.pdf)

Core contributions of the paper:
- Rigorous mathematical foundation of DTL and Metatron structure
- Proof of the 58.5% information advantage
- Complete spectral analysis of the Hamilton operator
- Implementation algorithms
- Roadmap for hardware realization

## Developer Team

Developer-friendly implementation:
- **Modular design**: Clear separation of components
- **Comprehensive documentation**: Docstrings for all functions
- **Type hints**: Python 3.8+ type annotations
- **Examples**: 7 complete demonstrations
- **Tests**: Unit tests for all core functions

## License

This project is open source and can be freely used for research and education.

## Contact & Contributions

Contributions are welcome! Please:
1. Fork the repository
2. Create a feature branch
3. Implement tests for new features
4. Create a pull request

---

**Status**: ✅ Fully implemented (Phase 1 + Phase 2)
**Version**: 1.0.0
**Date**: 2025-11-11
