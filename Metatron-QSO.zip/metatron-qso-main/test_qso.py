"""
Unit Tests for Quantum State Operator

Comprehensive test suite for all QSO components.
"""

import unittest
import numpy as np
from typing import List

from quantum_state import QuantumState, QuantumUnitaryOperator, METATRON_DIMENSION
from dtl import DTLState, DTLOperations, DTLResonator, TripolarInformationTheory
from metatron_graph import MetatronGraph
from qso import QuantumStateOperator, QSOParameters


class TestQuantumState(unittest.TestCase):
    """Tests for QuantumState class."""

    def test_creation_and_normalization(self):
        """Test quantum state creation and normalization."""
        amps = [1.0 + 0j, 1.0 + 0j, 1.0 + 0j]
        state = QuantumState(amps, normalize=True)

        self.assertEqual(len(state.amplitudes), METATRON_DIMENSION)
        self.assertTrue(state.is_normalized(tolerance=1e-10))
        self.assertAlmostEqual(state.norm(), 1.0, places=10)

    def test_basis_state(self):
        """Test basis state creation."""
        for node in range(METATRON_DIMENSION):
            state = QuantumState.basis_state(node)
            probs = state.probabilities()

            self.assertAlmostEqual(probs[node], 1.0, places=10)
            self.assertAlmostEqual(np.sum(probs) - probs[node], 0.0, places=10)

    def test_uniform_superposition(self):
        """Test uniform superposition."""
        state = QuantumState.uniform_superposition()
        probs = state.probabilities()

        expected_prob = 1.0 / METATRON_DIMENSION
        for prob in probs:
            self.assertAlmostEqual(prob, expected_prob, places=10)

    def test_inner_product(self):
        """Test inner product calculation."""
        state1 = QuantumState.basis_state(0)
        state2 = QuantumState.basis_state(0)
        state3 = QuantumState.basis_state(1)

        # ⟨ψ|ψ⟩ = 1
        self.assertAlmostEqual(state1.inner_product(state2), 1.0 + 0j, places=10)

        # ⟨0|1⟩ = 0
        self.assertAlmostEqual(state1.inner_product(state3), 0.0 + 0j, places=10)

    def test_measurement(self):
        """Test quantum measurement."""
        state = QuantumState.basis_state(5)
        measurement = state.measure()

        # Should always measure node 6 (1-based)
        self.assertEqual(measurement, 6)


class TestQuantumUnitaryOperator(unittest.TestCase):
    """Tests for QuantumUnitaryOperator class."""

    def test_identity_operator(self):
        """Test identity operator."""
        op = QuantumUnitaryOperator.identity()

        self.assertTrue(op.is_unitary(atol=1e-8))
        self.assertEqual(op.matrix.shape, (METATRON_DIMENSION, METATRON_DIMENSION))

    def test_permutation_operator(self):
        """Test permutation operator."""
        # Cyclic permutation
        sigma = list(range(2, METATRON_DIMENSION + 1)) + [1]
        op = QuantumUnitaryOperator.from_permutation(sigma)

        self.assertTrue(op.is_unitary(atol=1e-8))

        # Apply to basis state
        state = QuantumState.basis_state(0)
        new_state = state.apply(op)
        probs = new_state.probabilities()

        # Probability should shift from node 0 to node 12
        self.assertAlmostEqual(probs[12], 1.0, places=10)

    def test_operator_composition(self):
        """Test operator composition."""
        op1 = QuantumUnitaryOperator.identity()
        op2 = QuantumUnitaryOperator.identity()

        composed = op1.compose(op2)

        self.assertTrue(composed.is_unitary(atol=1e-8))
        self.assertTrue(np.allclose(composed.matrix, op1.matrix))

    def test_adjoint(self):
        """Test adjoint operation."""
        sigma = list(range(2, METATRON_DIMENSION + 1)) + [1]
        op = QuantumUnitaryOperator.from_permutation(sigma)
        adj = op.adjoint()

        # U†U = I
        product = adj.compose(op)
        identity = QuantumUnitaryOperator.identity()

        self.assertTrue(np.allclose(product.matrix, identity.matrix, atol=1e-10))


class TestDTL(unittest.TestCase):
    """Tests for Dynamic Tripolar Logic."""

    def test_static_states(self):
        """Test static L0 and L1 states."""
        L0 = DTLState.L0()
        L1 = DTLState.L1()

        self.assertEqual(L0.evaluate(0), 0.0)
        self.assertEqual(L0.evaluate(100), 0.0)
        self.assertEqual(L1.evaluate(0), 1.0)
        self.assertEqual(L1.evaluate(100), 1.0)

    def test_dtl_operations(self):
        """Test DTL logical operations."""
        L0 = DTLState.L0()
        L1 = DTLState.L1()

        # AND
        self.assertEqual(DTLOperations.AND(L0, L0).value, 0.0)
        self.assertEqual(DTLOperations.AND(L0, L1).value, 0.0)
        self.assertEqual(DTLOperations.AND(L1, L1).value, 1.0)

        # OR
        self.assertEqual(DTLOperations.OR(L0, L0).value, 0.0)
        self.assertEqual(DTLOperations.OR(L0, L1).value, 1.0)
        self.assertEqual(DTLOperations.OR(L1, L1).value, 1.0)

        # NOT
        self.assertEqual(DTLOperations.NOT(L0).value, 1.0)
        self.assertEqual(DTLOperations.NOT(L1).value, 0.0)

    def test_oscillatory_state(self):
        """Test oscillatory LD state."""
        LD = DTLState.LD_oscillatory(frequency=1.0, phase=0, amplitude=0.5, offset=0.5)

        # At t=0: offset + amplitude*sin(0) = 0.5
        self.assertAlmostEqual(LD.evaluate(0), 0.5, places=6)

        # Should oscillate
        values = [LD.evaluate(t) for t in np.linspace(0, 1, 100)]
        self.assertTrue(max(values) > min(values))
        self.assertTrue(all(0 <= v <= 1 for v in values))

    def test_information_capacity(self):
        """Test tripolar information capacity."""
        c_tri = TripolarInformationTheory.channel_capacity_tripolar()
        c_bin = TripolarInformationTheory.channel_capacity_binary()

        self.assertAlmostEqual(c_tri, np.log2(3), places=10)
        self.assertEqual(c_bin, 1.0)

        advantage = TripolarInformationTheory.relative_advantage()
        self.assertAlmostEqual(advantage, np.log2(3) - 1, places=10)


class TestMetatronGraph(unittest.TestCase):
    """Tests for Metatron Graph structure."""

    def test_graph_construction(self):
        """Test graph is properly constructed."""
        graph = MetatronGraph()

        self.assertEqual(graph.num_nodes, 13)
        self.assertGreater(len(graph.edges), 0)

    def test_adjacency_matrix(self):
        """Test adjacency matrix properties."""
        graph = MetatronGraph()
        A = graph.get_adjacency_matrix()

        # Symmetric
        self.assertTrue(np.allclose(A, A.T))

        # Binary entries
        self.assertTrue(np.all((A == 0) | (A == 1)))

        # No self-loops
        self.assertTrue(np.all(np.diag(A) == 0))

    def test_laplacian_matrix(self):
        """Test Laplacian matrix properties."""
        graph = MetatronGraph()
        L = graph.get_laplacian_matrix()

        # Symmetric
        self.assertTrue(np.allclose(L, L.T))

        # Row sums are zero
        row_sums = np.sum(L, axis=1)
        self.assertTrue(np.allclose(row_sums, 0))

        # Eigenvalues
        eigenvalues = np.linalg.eigvalsh(L)

        # Smallest eigenvalue is 0
        self.assertAlmostEqual(eigenvalues[0], 0.0, places=10)

        # All eigenvalues non-negative
        self.assertTrue(np.all(eigenvalues >= -1e-10))

    def test_connectivity(self):
        """Test graph connectivity."""
        graph = MetatronGraph()
        stats = graph.get_statistics()

        self.assertTrue(stats['is_connected'])
        self.assertGreater(stats['diameter'], 0)

    def test_node_coordinates(self):
        """Test node coordinates."""
        graph = MetatronGraph()
        coords = graph.get_node_coordinates()

        self.assertEqual(coords.shape, (13, 3))

        # Center node at origin
        self.assertTrue(np.allclose(coords[0], [0, 0, 0]))


class TestMetatronHamiltonian(unittest.TestCase):
    """Tests for Metatron-Hamilton Operator."""

    def test_hamiltonian_construction(self):
        """Test Hamilton operator construction."""
        params = QSOParameters(J=1.0)
        qso = QuantumStateOperator(params)

        H = qso.hamiltonian.hamiltonian

        # Hermitian
        self.assertTrue(np.allclose(H, H.T.conj()))

        # Correct shape
        self.assertEqual(H.shape, (METATRON_DIMENSION, METATRON_DIMENSION))

    def test_spectrum(self):
        """Test spectral properties."""
        params = QSOParameters(J=1.0)
        qso = QuantumStateOperator(params)

        eigenvalues = qso.hamiltonian.eigenvalues

        # Real eigenvalues (Hermitian operator)
        self.assertTrue(np.all(np.isreal(eigenvalues)))

        # 13 eigenvalues
        self.assertEqual(len(eigenvalues), METATRON_DIMENSION)

        # Sorted
        self.assertTrue(np.all(eigenvalues[:-1] <= eigenvalues[1:]))

    def test_time_evolution(self):
        """Test time evolution unitarity."""
        params = QSOParameters(J=1.0)
        qso = QuantumStateOperator(params)

        initial_state = qso.get_basis_state(0)
        evolved_state = qso.evolve_quantum_state(initial_state, time=1.0)

        # State should remain normalized
        self.assertTrue(evolved_state.is_normalized(tolerance=1e-10))

        # Probability conservation
        self.assertAlmostEqual(np.sum(evolved_state.probabilities()), 1.0, places=10)

    def test_ground_state(self):
        """Test ground state properties."""
        params = QSOParameters(J=1.0)
        qso = QuantumStateOperator(params)

        ground_state = qso.get_ground_state()

        # Normalized
        self.assertTrue(ground_state.is_normalized(tolerance=1e-10))

        # Eigenstate
        H_psi = ground_state.apply(QuantumUnitaryOperator(qso.hamiltonian.hamiltonian))
        E_0 = qso.hamiltonian.eigenvalues[0]

        expected = ground_state.amplitudes * E_0
        self.assertTrue(np.allclose(H_psi.amplitudes, expected, atol=1e-10))


class TestSymmetryGroup(unittest.TestCase):
    """Tests for Symmetry Group."""

    def test_generators(self):
        """Test symmetry generators."""
        params = QSOParameters()
        qso = QuantumStateOperator(params)

        generators = qso.symmetry.generators

        # Should have at least one generator
        self.assertGreater(len(generators), 0)

        # Generators are permutation matrices (orthogonal)
        for g in generators:
            product = g @ g.T
            identity = np.eye(METATRON_DIMENSION)
            self.assertTrue(np.allclose(product, identity, atol=1e-10))

    def test_laplacian_symmetry(self):
        """Test Laplacian is G_M-invariant."""
        params = QSOParameters()
        qso = QuantumStateOperator(params)

        L = qso.graph.get_laplacian_matrix()
        is_symmetric = qso.symmetry.is_symmetric_operator(L)

        # Note: Depending on edge construction, this may or may not be true
        # The test verifies the checking mechanism works
        self.assertIsInstance(is_symmetric, bool)


class TestResonatorNetwork(unittest.TestCase):
    """Tests for DTL Resonator Network."""

    def test_network_initialization(self):
        """Test resonator network initialization."""
        params = QSOParameters(omega=np.zeros(13), kappa=1.0)
        qso = QuantumStateOperator(params)

        network = qso.resonator_network

        self.assertEqual(network.num_nodes, 13)
        self.assertEqual(len(network.phases), 13)

    def test_dynamics_integration(self):
        """Test resonator dynamics integration."""
        params = QSOParameters(omega=np.zeros(13), kappa=1.0)
        qso = QuantumStateOperator(params)

        times, phases = qso.simulate_resonator_dynamics((0, 5), dt=0.1)

        # Check shapes
        self.assertGreater(len(times), 0)
        self.assertEqual(phases.shape[0], len(times))
        self.assertEqual(phases.shape[1], 13)

    def test_order_parameter(self):
        """Test Kuramoto order parameter."""
        params = QSOParameters(omega=np.zeros(13), kappa=1.0)
        qso = QuantumStateOperator(params)

        # All phases equal -> r = 1
        phases_sync = np.zeros(13)
        r_sync = qso.resonator_network.compute_order_parameter(phases_sync)
        self.assertAlmostEqual(r_sync, 1.0, places=10)

        # Uniformly distributed phases -> r ≈ 0
        phases_random = np.linspace(0, 2*np.pi, 13)
        r_random = qso.resonator_network.compute_order_parameter(phases_random)
        self.assertLess(r_random, 0.5)


class TestQSO(unittest.TestCase):
    """Integration tests for complete QSO."""

    def test_qso_initialization(self):
        """Test QSO initializes all components."""
        qso = QuantumStateOperator()

        self.assertIsNotNone(qso.graph)
        self.assertIsNotNone(qso.hamiltonian)
        self.assertIsNotNone(qso.symmetry)
        self.assertIsNotNone(qso.resonator_network)

    def test_quantum_dtl_correspondence(self):
        """Test quantum to DTL mapping."""
        qso = QuantumStateOperator()

        state = qso.get_basis_state(0)
        dtl_values = qso.quantum_to_dtl_correspondence(state)

        # Should have 13 values
        self.assertEqual(len(dtl_values), 13)

        # Sum to 1 (probabilities)
        self.assertAlmostEqual(np.sum(dtl_values), 1.0, places=10)

        # First node has probability 1
        self.assertAlmostEqual(dtl_values[0], 1.0, places=10)


def run_tests():
    """Run all tests."""
    # Create test suite
    loader = unittest.TestLoader()
    suite = unittest.TestSuite()

    # Add all test classes
    suite.addTests(loader.loadTestsFromTestCase(TestQuantumState))
    suite.addTests(loader.loadTestsFromTestCase(TestQuantumUnitaryOperator))
    suite.addTests(loader.loadTestsFromTestCase(TestDTL))
    suite.addTests(loader.loadTestsFromTestCase(TestMetatronGraph))
    suite.addTests(loader.loadTestsFromTestCase(TestMetatronHamiltonian))
    suite.addTests(loader.loadTestsFromTestCase(TestSymmetryGroup))
    suite.addTests(loader.loadTestsFromTestCase(TestResonatorNetwork))
    suite.addTests(loader.loadTestsFromTestCase(TestQSO))

    # Run tests
    runner = unittest.TextTestRunner(verbosity=2)
    result = runner.run(suite)

    # Summary
    print("\n" + "=" * 70)
    print("TEST SUMMARY")
    print("=" * 70)
    print(f"Tests run: {result.testsRun}")
    print(f"Successes: {result.testsRun - len(result.failures) - len(result.errors)}")
    print(f"Failures: {len(result.failures)}")
    print(f"Errors: {len(result.errors)}")
    print("=" * 70)

    return result.wasSuccessful()


if __name__ == "__main__":
    success = run_tests()
    exit(0 if success else 1)
