"""
QSO Quantum State Oscillator - Setup Configuration
Framework for Quantum Walks and Hybrid Quantum-Classical Algorithms
"""

from setuptools import setup, find_packages

with open('README.md', 'r', encoding='utf-8') as f:
    long_description = f.read()

setup(
    name='metatron-qso',
    version='1.0.0',
    description='Quantum State Oscillator on Metatron Cube - Quantum Computing Framework',
    long_description=long_description,
    long_description_content_type='text/markdown',
    author='QSO Research Team',
    author_email='research@qso.dev',
    url='https://github.com/LashSesh/metatron-qso',
    license='MIT',
    packages=find_packages(),
    py_modules=[
        'quantum_walks',
        'qso',
        'quantum_state',
        'metatron_graph',
        'dtl',
        'examples',
        'test_qso'
    ],
    python_requires='>=3.9',
    install_requires=[
        'numpy>=1.21.0',
        'scipy>=1.7.0',
        'matplotlib>=3.5.0',
        'networkx>=2.6.0',
    ],
    extras_require={
        'dev': [
            'pytest>=7.0.0',
            'pytest-cov>=3.0.0',
            'pytest-benchmark>=3.4.0',
            'scikit-optimize>=0.9.0',
        ],
        'jupyter': [
            'jupyter>=1.0.0',
            'jupyterlab>=3.0.0',
            'ipython>=7.0.0',
            'plotly>=5.0.0',
        ],
        'all': [
            'pytest>=7.0.0',
            'pytest-cov>=3.0.0',
            'pytest-benchmark>=3.4.0',
            'scikit-optimize>=0.9.0',
            'jupyter>=1.0.0',
            'jupyterlab>=3.0.0',
            'ipython>=7.0.0',
            'plotly>=5.0.0',
        ],
    },
    classifiers=[
        'Development Status :: 4 - Beta',
        'Intended Audience :: Science/Research',
        'Intended Audience :: Developers',
        'Topic :: Scientific/Engineering :: Physics',
        'Topic :: Scientific/Engineering :: Artificial Intelligence',
        'License :: OSI Approved :: MIT License',
        'Programming Language :: Python :: 3',
        'Programming Language :: Python :: 3.9',
        'Programming Language :: Python :: 3.10',
        'Programming Language :: Python :: 3.11',
    ],
    keywords=[
        'quantum computing',
        'quantum walks',
        'variational quantum algorithms',
        'VQE',
        'QAOA',
        'quantum machine learning',
        'Metatron cube',
        'sacred geometry',
        'hybrid quantum-classical',
    ],
    project_urls={
        'Documentation': 'https://github.com/LashSesh/metatron-qso/blob/main/README.md',
        'Source': 'https://github.com/LashSesh/metatron-qso',
        'Tracker': 'https://github.com/LashSesh/metatron-qso/issues',
    },
)
