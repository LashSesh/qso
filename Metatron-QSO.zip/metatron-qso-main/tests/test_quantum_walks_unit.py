"""
Unit Tests for Quantum Walks Module

Comprehensive unit tests for quantum walk implementations, ensuring
correctness of quantum mechanics, graph operations, and benchmark metrics.

Run with:
    pytest tests/test_quantum_walks_unit.py -v
"""

import pytest
import numpy as np
from scipy.linalg import expm

from quantum_walks import (
    QuantumWalk,
    ContinuousQuantumWalk,
    DiscreteQuantumWalk,
    ClassicalRandomWalk,
    compare_quantum_classical
)
from metatron_graph import MetatronGraph
from quantum_state import QuantumState


# ============================================================================
# Fixtures
# ============================================================================

@pytest.fixture
def metatron_graph():
    """Fixture providing Metatron Cube graph."""
    return MetatronGraph()


@pytest.fixture
def ctqw(metatron_graph):
    """Fixture providing Continuous Quantum Walk."""
    return ContinuousQuantumWalk(metatron_graph)


@pytest.fixture
def dtqw(metatron_graph):
    """Fixture providing Discrete Quantum Walk."""
    return DiscreteQuantumWalk(metatron_graph, dt=0.1)


@pytest.fixture
def classical_walk(metatron_graph):
    """Fixture providing Classical Random Walk."""
    return ClassicalRandomWalk(metatron_graph, seed=42)


# ============================================================================
# Test Quantum Walk Base Class
# ============================================================================

class TestQuantumWalkBase:
    """Test base QuantumWalk functionality."""

    def test_initialization_default_state(self, metatron_graph):
        """Test initialization with default uniform superposition."""
        qw = ContinuousQuantumWalk(metatron_graph)

        # Should initialize with uniform superposition
        expected_amplitude = 1.0 / np.sqrt(13)
        assert np.allclose(np.abs(qw.state.amplitudes), expected_amplitude)

    def test_initialization_custom_state(self, metatron_graph):
        """Test initialization with custom state."""
        custom_state = QuantumState.basis_state(0)
        qw = ContinuousQuantumWalk(metatron_graph, initial_state=custom_state)

        # Should use provided state
        assert np.allclose(qw.state.amplitudes, custom_state.amplitudes)

    def test_reset_functionality(self, metatron_graph):
        """Test reset returns to initial state."""
        # Use basis state for clearer evolution
        initial_state = QuantumState.basis_state(0)
        qw = ContinuousQuantumWalk(metatron_graph, initial_state=initial_state)

        initial = qw.state.amplitudes.copy()

        # Evolve
        qw.evolve(time=5.0)
        after_evolution = qw.state.amplitudes.copy()

        # Should be different after evolution (check L2 distance)
        diff = np.linalg.norm(after_evolution - initial)
        assert diff > 0.1, f"Evolution should change state significantly, diff={diff}"

        # Reset
        qw.reset()
        after_reset = qw.state.amplitudes.copy()

        # Should match initial state
        assert np.allclose(after_reset, initial)

    def test_probability_distribution(self, ctqw):
        """Test probability distribution extraction."""
        ctqw.reset()
        prob_dist = ctqw.get_probability_distribution()

        # Should be real and non-negative
        assert np.all(prob_dist >= 0)
        assert np.all(np.isreal(prob_dist))

        # Should sum to 1
        assert np.isclose(np.sum(prob_dist), 1.0)

    def test_stationary_distribution(self, ctqw):
        """Test stationary distribution calculation."""
        stationary = ctqw.get_stationary_distribution()

        # Should be non-negative
        assert np.all(stationary >= 0)

        # Should sum to 1
        assert np.isclose(np.sum(stationary), 1.0)

        # For Metatron (highly symmetric), should be close to uniform
        # but not exactly uniform due to different degrees
        expected_uniform = 1.0 / 13
        assert np.allclose(stationary, expected_uniform, atol=0.1)


# ============================================================================
# Test Continuous Quantum Walk (CTQW)
# ============================================================================

class TestContinuousQuantumWalk:
    """Test CTQW implementation."""

    def test_unitarity_preservation(self, ctqw):
        """Test that evolution preserves unitarity (norm)."""
        ctqw.reset()

        # Evolve for various times
        for t in [0.1, 1.0, 5.0, 10.0]:
            ctqw.evolve(t, from_initial=True)
            norm = np.sum(np.abs(ctqw.state.amplitudes) ** 2)
            assert np.isclose(norm, 1.0), f"Norm violated at t={t}: {norm}"

    def test_hamiltonian_hermiticity(self, ctqw):
        """Test that Hamiltonian is Hermitian."""
        H = ctqw.hamiltonian
        diff = np.linalg.norm(H - H.T.conj())
        assert diff < 1e-12, "Hamiltonian must be Hermitian"

    def test_eigendecomposition(self, ctqw):
        """Test eigendecomposition precomputation."""
        # Check that eigenvalues and eigenvectors exist
        assert hasattr(ctqw, 'eigenvalues')
        assert hasattr(ctqw, 'eigenvectors')

        # Check dimensions
        assert len(ctqw.eigenvalues) == 13
        assert ctqw.eigenvectors.shape == (13, 13)

        # Verify eigendecomposition: H = V Λ V†
        H_reconstructed = ctqw.eigenvectors @ np.diag(ctqw.eigenvalues) @ ctqw.eigenvectors.T.conj()
        assert np.allclose(H_reconstructed, ctqw.hamiltonian)

    def test_time_reversal(self, ctqw):
        """Test time reversal symmetry."""
        ctqw.reset()
        initial = ctqw.state.amplitudes.copy()

        # Evolve forward
        ctqw.evolve(5.0, from_initial=True)
        forward = ctqw.state.amplitudes.copy()

        # Evolve backward
        ctqw.state = QuantumState(forward)
        ctqw.evolve(-5.0, from_initial=False)
        backward = ctqw.state.amplitudes.copy()

        # Should return to initial (up to phase)
        overlap = np.abs(np.vdot(backward, initial))
        assert np.isclose(overlap, 1.0, atol=1e-10)

    def test_spectral_info(self, ctqw):
        """Test spectral information extraction."""
        info = ctqw.get_spectral_info()

        # Check required fields
        assert 'eigenvalues' in info
        assert 'ground_state_energy' in info
        assert 'spectral_gap' in info
        assert 'spectral_gaps' in info
        assert 'energy_range' in info

        # Check properties
        assert len(info['eigenvalues']) == 13
        assert info['spectral_gap'] >= 0
        assert info['energy_range'] >= 0

    def test_evolution_consistency(self, ctqw):
        """Test that multiple small steps equal one large step."""
        ctqw.reset()

        # Evolve in small steps
        ctqw.reset()
        for _ in range(10):
            ctqw.evolve(0.1, from_initial=False)
        small_steps = ctqw.state.amplitudes.copy()

        # Evolve in one large step
        ctqw.evolve(1.0, from_initial=True)
        large_step = ctqw.state.amplitudes.copy()

        # Should be equivalent
        assert np.allclose(small_steps, large_step, atol=1e-10)


# ============================================================================
# Test Discrete Quantum Walk (DTQW)
# ============================================================================

class TestDiscreteQuantumWalk:
    """Test DTQW implementation."""

    def test_step_operator_unitarity(self, dtqw):
        """Test that step operator is unitary."""
        U = dtqw.step_operator

        # U†U should equal identity
        identity = U.T.conj() @ U
        assert np.allclose(identity, np.eye(13), atol=1e-12)

    def test_discrete_evolution_preserves_norm(self, dtqw):
        """Test that discrete evolution preserves norm."""
        dtqw.reset()

        for steps in [1, 10, 100]:
            dtqw.reset()
            dtqw.evolve_steps(steps)
            norm = np.sum(np.abs(dtqw.state.amplitudes) ** 2)
            assert np.isclose(norm, 1.0), f"Norm violated after {steps} steps"

    def test_discrete_steps_vs_time_evolution(self, dtqw):
        """Test that evolve_steps matches evolve with time."""
        dtqw.reset()
        dtqw.evolve_steps(10)
        steps_result = dtqw.state.amplitudes.copy()

        dtqw.reset()
        dtqw.evolve(1.0, from_initial=True)  # 10 steps * 0.1 dt = 1.0
        time_result = dtqw.state.amplitudes.copy()

        assert np.allclose(steps_result, time_result, atol=1e-10)

    def test_timestep_consistency(self, metatron_graph):
        """Test that different timesteps converge to same continuous limit."""
        # Small timestep
        dtqw_small = DiscreteQuantumWalk(metatron_graph, dt=0.01)
        dtqw_small.evolve_steps(100)  # Total time = 1.0
        result_small = dtqw_small.get_probability_distribution()

        # Larger timestep
        dtqw_large = DiscreteQuantumWalk(metatron_graph, dt=0.1)
        dtqw_large.evolve_steps(10)  # Total time = 1.0
        result_large = dtqw_large.get_probability_distribution()

        # Should be similar (not exact due to discretization)
        assert np.allclose(result_small, result_large, atol=0.1)


# ============================================================================
# Test Classical Random Walk
# ============================================================================

class TestClassicalRandomWalk:
    """Test classical random walk implementation."""

    def test_transition_matrix_stochastic(self, classical_walk):
        """Test that transition matrix is row-stochastic."""
        T = classical_walk.transition_matrix

        # Each row should sum to 1
        row_sums = np.sum(T, axis=1)
        assert np.allclose(row_sums, 1.0)

        # All entries should be non-negative
        assert np.all(T >= 0)

    def test_reset_functionality(self, classical_walk):
        """Test reset returns to initial node."""
        classical_walk.step()
        classical_walk.step()
        classical_walk.reset()

        assert classical_walk.current_node == classical_walk.initial_node

    def test_step_moves_to_neighbor(self, classical_walk):
        """Test that step moves to a valid neighbor."""
        initial = classical_walk.current_node
        classical_walk.step()
        new_node = classical_walk.current_node

        # Should have moved (very high probability)
        # or stayed (if self-loop, which Metatron doesn't have)
        adjacency = classical_walk.graph.get_adjacency_matrix()
        assert adjacency[initial, new_node] > 0 or initial == new_node

    def test_reproducibility_with_seed(self, metatron_graph):
        """Test that same seed produces same walk."""
        walk1 = ClassicalRandomWalk(metatron_graph, seed=123)
        walk2 = ClassicalRandomWalk(metatron_graph, seed=123)

        # Take same number of steps
        for _ in range(100):
            walk1.step()
            walk2.step()

        # Should be at same position
        assert walk1.current_node == walk2.current_node


# ============================================================================
# Test Benchmark Metrics
# ============================================================================

class TestBenchmarkMetrics:
    """Test benchmark metric calculations."""

    def test_mixing_time_convergence(self, ctqw):
        """Test that mixing time is finite and reasonable."""
        mixing_time, tv_distances = ctqw.get_mixing_time(epsilon=0.01, max_time=50.0, dt=0.1)

        # Should converge within reasonable time
        assert mixing_time < 50.0

        # Should be in expected range for Metatron (4-8 steps)
        assert 2 <= mixing_time <= 15

        # TV distance should decrease over time (generally)
        assert tv_distances[0] > tv_distances[-1]

    def test_hitting_time_validity(self, ctqw):
        """Test hitting time calculation."""
        ht = ctqw.get_hitting_time(0, 6, threshold=0.5, max_time=30.0, dt=0.1)

        # Should be finite
        assert 0 < ht <= 30.0

        # Should be reasonable (not instant, not maximum)
        assert ht > 0.1

    def test_return_probability_bounds(self, ctqw):
        """Test return probability is valid probability."""
        for start_node in [0, 5, 10]:
            for t in [1.0, 5.0, 10.0]:
                prob = ctqw.get_return_probability(start_node, t)
                assert 0 <= prob <= 1, f"Invalid probability: {prob}"

    def test_total_variation_distance_bounds(self, ctqw):
        """Test TV distance is in valid range."""
        ctqw.reset()

        for t in [0, 1, 5, 10]:
            ctqw.evolve(t, from_initial=True)
            tv_dist = ctqw.total_variation_distance()
            assert 0 <= tv_dist <= 1, f"Invalid TV distance: {tv_dist}"

    def test_kl_divergence_non_negative(self, ctqw):
        """Test KL divergence is non-negative."""
        ctqw.reset()

        for t in [0, 1, 5, 10]:
            ctqw.evolve(t, from_initial=True)
            kl_div = ctqw.kullback_leibler_divergence()
            assert kl_div >= 0, f"KL divergence must be non-negative: {kl_div}"


# ============================================================================
# Test Quantum vs Classical Comparison
# ============================================================================

class TestQuantumVsClassical:
    """Test quantum vs classical comparison functionality."""

    def test_comparison_function_runs(self, metatron_graph):
        """Test that comparison function executes without errors."""
        result = compare_quantum_classical(metatron_graph, verbose=False)

        # Check required fields
        assert 'quantum_mixing_time' in result
        assert 'classical_mixing_time' in result
        assert 'mixing_speedup' in result
        assert 'avg_hitting_speedup' in result

    def test_quantum_advantage_exists(self, metatron_graph):
        """Test that quantum walk shows advantage over classical."""
        result = compare_quantum_classical(metatron_graph, verbose=False)

        # Quantum should generally be faster (speedup > 1)
        # Note: This is a statistical test, might occasionally fail
        assert result['mixing_speedup'] > 0.5  # Very conservative bound

    def test_all_metrics_positive(self, metatron_graph):
        """Test that all timing metrics are positive."""
        result = compare_quantum_classical(metatron_graph, verbose=False)

        assert result['quantum_mixing_time'] > 0
        assert result['classical_mixing_time'] > 0
        assert all(t > 0 for t in result['quantum_hitting_times'])
        assert all(t > 0 for t in result['classical_hitting_times'])


# ============================================================================
# Test Edge Cases and Error Handling
# ============================================================================

class TestEdgeCases:
    """Test edge cases and boundary conditions."""

    def test_zero_time_evolution(self, ctqw):
        """Test evolution at t=0 (should be identity)."""
        ctqw.reset()
        initial = ctqw.state.amplitudes.copy()

        ctqw.evolve(0.0, from_initial=True)
        after = ctqw.state.amplitudes.copy()

        assert np.allclose(initial, after)

    def test_negative_time_evolution(self, ctqw):
        """Test evolution with negative time (backward evolution)."""
        ctqw.reset()

        # Forward then backward should return to initial
        ctqw.evolve(5.0, from_initial=True)
        ctqw.evolve(-5.0, from_initial=False)
        final = ctqw.state.amplitudes.copy()

        initial = ctqw._initial_state.amplitudes
        overlap = np.abs(np.vdot(final, initial))
        assert np.isclose(overlap, 1.0, atol=1e-10)

    def test_very_long_evolution(self, ctqw):
        """Test that very long evolution maintains normalization."""
        ctqw.reset()
        ctqw.evolve(1000.0, from_initial=True)

        norm = np.sum(np.abs(ctqw.state.amplitudes) ** 2)
        assert np.isclose(norm, 1.0, atol=1e-8)

    def test_mixing_time_early_convergence(self, metatron_graph):
        """Test mixing time when already near stationary."""
        # Start in near-stationary distribution
        near_stationary = np.ones(13, dtype=complex) / np.sqrt(13)
        qw = ContinuousQuantumWalk(metatron_graph, QuantumState(near_stationary))

        mixing_time, _ = qw.get_mixing_time(epsilon=0.1, max_time=10.0, dt=0.1)

        # Should converge quickly
        assert mixing_time < 10.0


# ============================================================================
# Test Numerical Stability
# ============================================================================

class TestNumericalStability:
    """Test numerical stability of implementations."""

    def test_repeated_evolution_stability(self, ctqw):
        """Test that repeated evolution maintains stability."""
        ctqw.reset()

        # Evolve many times
        for _ in range(1000):
            ctqw.evolve(0.01, from_initial=False)

        # Check normalization
        norm = np.sum(np.abs(ctqw.state.amplitudes) ** 2)
        assert np.isclose(norm, 1.0, atol=1e-6)

    def test_small_timestep_accuracy(self, metatron_graph):
        """Test accuracy with very small timesteps."""
        dtqw_tiny = DiscreteQuantumWalk(metatron_graph, dt=0.001)
        ctqw = ContinuousQuantumWalk(metatron_graph)

        # Evolve to same time
        dtqw_tiny.evolve(1.0, from_initial=True)
        ctqw.evolve(1.0, from_initial=True)

        dtqw_prob = dtqw_tiny.get_probability_distribution()
        ctqw_prob = ctqw.get_probability_distribution()

        # Should be very close with tiny timestep
        assert np.allclose(dtqw_prob, ctqw_prob, atol=0.01)


# ============================================================================
# Performance Sanity Checks
# ============================================================================

class TestPerformanceSanity:
    """Sanity checks for performance (not strict benchmarks)."""

    def test_evolution_completes_quickly(self, ctqw):
        """Test that single evolution completes in reasonable time."""
        import time

        start = time.time()
        ctqw.evolve(10.0)
        elapsed = time.time() - start

        # Should complete in less than 1 second
        assert elapsed < 1.0

    def test_mixing_time_computation_reasonable(self, ctqw):
        """Test that mixing time computation is not excessively slow."""
        import time

        start = time.time()
        ctqw.get_mixing_time(epsilon=0.01, max_time=20.0, dt=0.2)
        elapsed = time.time() - start

        # Should complete in less than 5 seconds
        assert elapsed < 5.0
