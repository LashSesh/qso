"""
Quantum State Operator - Examples and Demonstrations

This module provides comprehensive examples demonstrating all features of the QSO.

Examples include:
1. Basic quantum state operations
2. DTL states and operations
3. Metatron graph analysis
4. Hamilton operator dynamics
5. DTL resonator network synchronization
6. Quantum-DTL correspondence
7. Symmetry operations
"""

import numpy as np
import matplotlib.pyplot as plt
from typing import List

from quantum_state import QuantumState, QuantumUnitaryOperator, METATRON_DIMENSION
from dtl import DTLState, DTLOperations, DTLResonator, TripolarInformationTheory, visualize_dtl_states
from metatron_graph import MetatronGraph
from qso import QuantumStateOperator, QSOParameters


def example_1_basic_quantum_states():
    """Example 1: Basic quantum state operations."""
    print("\n" + "=" * 70)
    print("EXAMPLE 1: BASIC QUANTUM STATE OPERATIONS")
    print("=" * 70 + "\n")

    # Create basis states
    state_0 = QuantumState.basis_state(0)
    print(f"Basis state |0⟩: {state_0.amplitudes[:3]}...")
    print(f"Norm: {state_0.norm()}")
    print(f"Is normalized: {state_0.is_normalized()}")

    # Create superposition
    state_super = QuantumState.uniform_superposition()
    print(f"\nUniform superposition:")
    print(f"Probabilities: {state_super.probabilities()[:5]}...")

    # Inner product
    inner = state_0.inner_product(state_super)
    print(f"\n⟨0|ψ_super⟩ = {inner}")

    # Random state
    state_random = QuantumState.random(seed=42)
    print(f"\nRandom state (Haar measure):")
    print(f"Amplitudes (first 3): {state_random.amplitudes[:3]}")

    # Apply permutation operator
    perm = list(range(1, METATRON_DIMENSION)) + [0]  # Cyclic shift
    op = QuantumUnitaryOperator.from_permutation(perm)
    print(f"\nPermutation operator is unitary: {op.is_unitary()}")

    state_permuted = state_0.apply(op)
    print(f"Permuted state probabilities: {state_permuted.probabilities()[:5]}...")

    print("\n" + "=" * 70 + "\n")


def example_2_dtl_states():
    """Example 2: Dynamic Tripolar Logic states."""
    print("\n" + "=" * 70)
    print("EXAMPLE 2: DYNAMIC TRIPOLAR LOGIC")
    print("=" * 70 + "\n")

    # Static states
    L0 = DTLState.L0()
    L1 = DTLState.L1()
    print(f"L0 at t=5: {L0.evaluate(5)}")
    print(f"L1 at t=5: {L1.evaluate(5)}")

    # Dynamic oscillatory state
    LD_osc = DTLState.LD_oscillatory(frequency=0.5, phase=0, amplitude=0.4, offset=0.5)
    print(f"LD oscillatory at t=0: {LD_osc.evaluate(0):.6f}")
    print(f"LD oscillatory at t=1: {LD_osc.evaluate(1):.6f}")
    print(f"LD oscillatory at t=2: {LD_osc.evaluate(2):.6f}")

    # DTL operations
    print(f"\nDTL Operations:")
    print(f"L0 ∧ L1 = {DTLOperations.AND(L0, L1).value}")
    print(f"L0 ∨ L1 = {DTLOperations.OR(L0, L1).value}")
    print(f"¬L0 = {DTLOperations.NOT(L0).value}")

    # Information capacity
    print(f"\nInformation Capacity:")
    c_tri = TripolarInformationTheory.channel_capacity_tripolar()
    c_bin = TripolarInformationTheory.channel_capacity_binary()
    advantage = TripolarInformationTheory.relative_advantage()
    print(f"Tripolar capacity: {c_tri:.6f} Bit/Symbol")
    print(f"Binary capacity: {c_bin:.6f} Bit/Symbol")
    print(f"Advantage: {advantage*100:.2f}%")

    print("\n" + "=" * 70 + "\n")


def example_3_metatron_graph():
    """Example 3: Metatron graph structure analysis."""
    print("\n" + "=" * 70)
    print("EXAMPLE 3: METATRON GRAPH ANALYSIS")
    print("=" * 70 + "\n")

    graph = MetatronGraph()

    # Statistics
    stats = graph.get_statistics()
    print(f"Nodes: {stats['num_nodes']}")
    print(f"Edges: {stats['num_edges']}")
    print(f"Average degree: {stats['avg_degree']:.2f}")
    print(f"Diameter: {stats['diameter']}")
    print(f"Connected: {stats['is_connected']}")

    # Laplacian spectrum
    laplacian = graph.get_laplacian_matrix()
    eigenvalues = np.linalg.eigvalsh(laplacian)
    print(f"\nLaplacian eigenvalues (λ):")
    for i, lam in enumerate(eigenvalues[:5]):
        print(f"  λ_{i}: {lam:.6f}")
    print(f"  ...")
    print(f"  Algebraic connectivity (λ₂): {eigenvalues[1]:.6f}")

    # Adjacency matrix structure
    A = graph.get_adjacency_matrix()
    print(f"\nAdjacency matrix A (7×7 submatrix):")
    print(A[:7, :7])

    print("\n" + "=" * 70 + "\n")


def example_4_hamilton_dynamics():
    """Example 4: Hamilton operator and time evolution."""
    print("\n" + "=" * 70)
    print("EXAMPLE 4: HAMILTONIAN DYNAMICS")
    print("=" * 70 + "\n")

    # Create QSO
    params = QSOParameters(J=1.0)
    qso = QuantumStateOperator(params)

    # Spectrum
    spectrum_info = qso.hamiltonian.get_spectrum_info()
    print(f"Ground state energy: {spectrum_info['ground_state_energy']:.6f}")
    print(f"Energy gap: {spectrum_info['energy_gap']:.6f}")

    # Get ground state
    ground_state = qso.get_ground_state()
    print(f"\nGround state probabilities:")
    probs = ground_state.probabilities()
    for i, p in enumerate(probs):
        print(f"  Node {i+1}: {p:.6f}")

    # Time evolution
    print(f"\nTime Evolution from |v1⟩:")
    initial = qso.get_basis_state(0)
    times = [0, 0.5, 1.0, 2.0, 5.0]

    for t in times:
        evolved = qso.evolve_quantum_state(initial, t)
        probs = evolved.probabilities()
        max_prob_node = np.argmax(probs)
        print(f"  t={t:.1f}: Max probability at node {max_prob_node+1} (P={probs[max_prob_node]:.4f})")

    print("\n" + "=" * 70 + "\n")


def example_5_resonator_network():
    """Example 5: DTL resonator network synchronization."""
    print("\n" + "=" * 70)
    print("EXAMPLE 5: DTL RESONATOR NETWORK SYNCHRONIZATION")
    print("=" * 70 + "\n")

    # Create resonator network
    params = QSOParameters(
        omega=np.random.randn(METATRON_DIMENSION) * 0.1,  # Random frequencies
        kappa=2.0  # Strong coupling
    )
    qso = QuantumStateOperator(params)

    # Check synchronization threshold
    kappa_c = qso.resonator_network.get_synchronization_threshold()
    print(f"Critical coupling κ_c: {kappa_c:.6f}")
    print(f"Current coupling κ: {params.kappa:.6f}")
    print(f"Expected to synchronize: {params.kappa > kappa_c}")

    # Simulate
    print(f"\nSimulating resonator dynamics...")
    times, phases = qso.simulate_resonator_dynamics((0, 20), dt=0.05)

    # Compute order parameter
    order_param = qso.resonator_network.compute_order_parameter(phases)

    print(f"Order parameter evolution:")
    sample_indices = [0, len(order_param)//4, len(order_param)//2, 3*len(order_param)//4, -1]
    for idx in sample_indices:
        print(f"  t={times[idx]:.2f}: r={order_param[idx]:.4f}")

    print(f"\nFinal synchronization level: r={order_param[-1]:.4f}")

    print("\n" + "=" * 70 + "\n")


def example_6_quantum_dtl_correspondence():
    """Example 6: Quantum state to DTL correspondence."""
    print("\n" + "=" * 70)
    print("EXAMPLE 6: QUANTUM-DTL CORRESPONDENCE")
    print("=" * 70 + "\n")

    qso = QuantumStateOperator()

    # Create quantum superposition
    amplitudes = np.zeros(METATRON_DIMENSION, dtype=complex)
    amplitudes[0] = 0.6 + 0.2j
    amplitudes[1] = 0.4 - 0.3j
    amplitudes[2] = 0.5 + 0.1j
    state = QuantumState(amplitudes, normalize=True)

    print(f"Quantum state amplitudes (first 3):")
    for i in range(3):
        alpha = state.amplitudes[i]
        print(f"  α_{i}: {alpha.real:.4f} + {alpha.imag:.4f}i")

    # DTL correspondence
    dtl_values = qso.quantum_to_dtl_correspondence(state)
    print(f"\nDTL values (probabilities):")
    for i in range(3):
        print(f"  x_{i} = |α_{i}|²: {dtl_values[i]:.6f}")

    # Phases
    phases = np.angle(state.amplitudes)
    print(f"\nPhases (for resonator correspondence):")
    for i in range(3):
        print(f"  φ_{i}: {phases[i]:.4f} rad")

    # Classification
    print(f"\nTripolar classification:")
    threshold = 0.01
    for i in range(METATRON_DIMENSION):
        x_i = dtl_values[i]
        if x_i < threshold:
            classification = "L0 (ground state)"
        elif x_i > 1 - threshold:
            classification = "L1 (excited state)"
        else:
            classification = "LD (superposition)"

        if i < 3 or x_i > threshold:
            print(f"  Node {i+1}: x={x_i:.4f} → {classification}")

    print("\n" + "=" * 70 + "\n")


def example_7_symmetry_operations():
    """Example 7: Symmetry group operations."""
    print("\n" + "=" * 70)
    print("EXAMPLE 7: SYMMETRY OPERATIONS")
    print("=" * 70 + "\n")

    qso = QuantumStateOperator()

    # Symmetry group info
    print(f"Symmetry group order: |G_M| = {qso.symmetry.get_order()}")
    print(f"Number of generators: {len(qso.symmetry.generators)}")

    # Check if Laplacian is symmetric
    L = qso.graph.get_laplacian_matrix()
    is_symmetric = qso.symmetry.is_symmetric_operator(L)
    print(f"\nLaplacian L is G_M-invariant: {is_symmetric}")

    # Check if Hamiltonian is symmetric
    H = qso.hamiltonian.hamiltonian
    is_symmetric = qso.symmetry.is_symmetric_operator(H)
    print(f"Hamiltonian H is G_M-invariant: {is_symmetric}")

    # Apply symmetry to a state
    state = qso.get_basis_state(1)  # |v2⟩ (hexagon node)
    print(f"\nOriginal state: |v2⟩ (hexagon node)")
    print(f"Probabilities: {state.probabilities()[:7]}")

    # Apply hexagonal rotation
    g = qso.symmetry.generators[0]  # Hexagonal rotation
    g_op = QuantumUnitaryOperator(g)
    rotated_state = state.apply(g_op)

    print(f"\nAfter hexagonal rotation:")
    print(f"Probabilities: {rotated_state.probabilities()[:7]}")
    print(f"(Note: Probability shifted from node 2 to node 3)")

    print("\n" + "=" * 70 + "\n")


def run_all_examples():
    """Run all examples sequentially."""
    print("\n" + "#" * 70)
    print("# QUANTUM STATE OPERATOR - COMPLETE EXAMPLES")
    print("#" * 70)

    example_1_basic_quantum_states()
    example_2_dtl_states()
    example_3_metatron_graph()
    example_4_hamilton_dynamics()
    example_5_resonator_network()
    example_6_quantum_dtl_correspondence()
    example_7_symmetry_operations()

    print("\n" + "#" * 70)
    print("# ALL EXAMPLES COMPLETED SUCCESSFULLY")
    print("#" * 70 + "\n")


if __name__ == "__main__":
    run_all_examples()
