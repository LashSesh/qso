"""
Metatron Cube - Graph Structure and Geometry

Implements the complete 13-node, 78-edge Metatron Cube graph structure
as specified in QSO.pdf Section 3.

The Metatron Cube is a sacred geometry pattern that contains all five Platonic solids
and exhibits rich symmetry properties. This module provides:
- Precise node coordinates in 3D space
- Complete edge connectivity (78 edges)
- Adjacency matrix construction
- Embedding of Platonic solids
- Graph-theoretic analysis tools

Node Structure:
--------------
- v1: Center node (C)
- v2-v7: Hexagon nodes (H1-H6)
- v8-v13: Cube corner nodes (Q1-Q6)

Total: 13 nodes, 78 edges
"""

import numpy as np
from typing import List, Tuple, Dict, Set, Optional
from dataclasses import dataclass
from enum import Enum
import networkx as nx


class NodeType(Enum):
    """Classification of Metatron Cube nodes."""
    CENTER = "C"
    HEXAGON = "H"
    CUBE = "Q"


@dataclass
class Node:
    """Metatron Cube node with coordinates and classification."""
    index: int  # 0-based
    node_type: NodeType
    coordinates: np.ndarray  # 3D position
    label: str


class MetatronGraph:
    """
    Metatron Cube Graph Structure.

    A complete representation of the Metatron Cube as a graph G_MC = (V, E)
    with 13 nodes and 78 edges, including:
    - Geometric embedding in ℝ³
    - Adjacency matrix
    - Platonic solid subgraphs
    - Symmetry group operations
    """

    def __init__(self):
        """Initialize Metatron Cube graph structure."""
        self.num_nodes = 13
        self.nodes: List[Node] = []
        self.edges: Set[Tuple[int, int]] = set()
        self.adjacency_matrix: np.ndarray = None

        self._build_nodes()
        self._build_edges()
        self._build_adjacency_matrix()

    def _build_nodes(self):
        """Construct the 13 nodes with 3D coordinates."""

        # v1: Center node at origin
        self.nodes.append(Node(
            index=0,
            node_type=NodeType.CENTER,
            coordinates=np.array([0.0, 0.0, 0.0]),
            label="v1 (C)"
        ))

        # v2-v7: Hexagon nodes in xy-plane
        for k in range(6):
            angle = 2 * np.pi * k / 6
            coords = np.array([np.cos(angle), np.sin(angle), 0.0])
            self.nodes.append(Node(
                index=k+1,
                node_type=NodeType.HEXAGON,
                coordinates=coords,
                label=f"v{k+2} (H{k+1})"
            ))

        # v8-v13: Cube corner nodes
        # Positioned at corners of axis-aligned cube with edge length √2
        sqrt2_inv = 1.0 / np.sqrt(2)
        cube_corners = [
            np.array([sqrt2_inv, sqrt2_inv, sqrt2_inv]),      # v8
            np.array([sqrt2_inv, sqrt2_inv, -sqrt2_inv]),     # v9
            np.array([sqrt2_inv, -sqrt2_inv, sqrt2_inv]),     # v10
            np.array([sqrt2_inv, -sqrt2_inv, -sqrt2_inv]),    # v11
            np.array([-sqrt2_inv, sqrt2_inv, sqrt2_inv]),     # v12
            np.array([-sqrt2_inv, -sqrt2_inv, -sqrt2_inv]),   # v13
        ]

        for j, coords in enumerate(cube_corners):
            self.nodes.append(Node(
                index=j+7,
                node_type=NodeType.CUBE,
                coordinates=coords,
                label=f"v{j+8} (Q{j+1})"
            ))

    def _build_edges(self):
        """
        Construct all 78 edges of the Metatron Cube.

        Edge categories (from QSO.pdf Appendix B):
        1. Center-Hexagon: 6 edges
        2. Hexagon ring: 6 edges
        3. Center-Cube: 6 edges
        4. Cube edges: 12 edges
        5. Hexagon-Cube connections: 12 edges
        6. Diagonal hexagon connections: 3 edges
        7. Additional structural edges: 33 edges
        Total: 78 edges
        """

        # Helper to add undirected edge (0-based indexing)
        def add_edge(i: int, j: int):
            if i != j:
                self.edges.add((min(i, j), max(i, j)))

        # 1. Center-Hexagon edges (6 edges)
        for k in range(1, 7):
            add_edge(0, k)

        # 2. Hexagon ring (6 edges)
        for k in range(1, 7):
            next_k = k + 1 if k < 6 else 1
            add_edge(k, next_k)

        # 3. Center-Cube edges (6 edges)
        for k in range(7, 13):
            add_edge(0, k)

        # 4. Cube edges (12 edges)
        # Cube topology: v8-v13 form axis-aligned cube
        cube_edges = [
            (7, 8), (7, 9), (7, 11),    # v8 connections
            (8, 10), (8, 11),           # v9 connections
            (9, 10), (9, 12),           # v10 connections
            (10, 12),                   # v11 connections
            (11, 12),                   # v12 connections
            (8, 9), (7, 12), (10, 11),  # Additional cube edges
        ]
        for i, j in cube_edges:
            add_edge(i, j)

        # 5. Hexagon-Cube connections (12 edges)
        hex_cube_connections = [
            (1, 7), (1, 8),   # v2 (H1)
            (2, 8), (2, 10),  # v3 (H2)
            (3, 10), (3, 12), # v4 (H3)
            (4, 12), (4, 9),  # v5 (H4)
            (5, 9), (5, 7),   # v6 (H5)
            (6, 11), (6, 12), # v7 (H6)
        ]
        for i, j in hex_cube_connections:
            add_edge(i, j)

        # 6. Diagonal hexagon connections (3 edges)
        add_edge(1, 4)  # v2-v5
        add_edge(2, 5)  # v3-v6
        add_edge(3, 6)  # v4-v7

        # 7. Additional structural edges for Platonic solid embeddings (33 edges)
        additional_edges = [
            # More hexagon-cube connections
            (1, 10), (1, 12), (2, 7), (2, 12),
            (3, 7), (3, 9), (4, 7), (4, 10),
            (5, 8), (5, 12), (6, 7), (6, 10),
            # Hexagon cross-connections
            (1, 3), (1, 5), (2, 4), (2, 6), (3, 5), (4, 6),
            # Additional cube-hexagon bridges
            (1, 9), (2, 11), (3, 8), (4, 11), (5, 10), (6, 8),
            # Inner cube diagonals
            (7, 10), (8, 12), (9, 11),
            # Cube to remaining hexagon connections
            (1, 11), (2, 9), (3, 11), (4, 8), (5, 11), (6, 9),
        ]
        for i, j in additional_edges:
            add_edge(i, j)

        # Note: The exact 78 edges depend on the specific geometric interpretation
        # The above construction ensures high connectivity for all Platonic embeddings

    def _build_adjacency_matrix(self):
        """Build adjacency matrix from edge set."""
        A = np.zeros((self.num_nodes, self.num_nodes), dtype=int)

        for i, j in self.edges:
            A[i, j] = 1
            A[j, i] = 1

        self.adjacency_matrix = A

    def get_adjacency_matrix(self) -> np.ndarray:
        """Get adjacency matrix (13×13)."""
        return self.adjacency_matrix.copy()

    def get_degree_matrix(self) -> np.ndarray:
        """Get degree matrix D = diag(d₁, ..., d₁₃)."""
        degrees = np.sum(self.adjacency_matrix, axis=1)
        return np.diag(degrees)

    def get_laplacian_matrix(self) -> np.ndarray:
        """
        Get graph Laplacian matrix L = D - A.

        The Laplacian is central to spectral analysis and quantum dynamics.

        Returns:
            Laplacian matrix (13×13)
        """
        D = self.get_degree_matrix()
        A = self.adjacency_matrix
        return D - A

    def get_node_coordinates(self) -> np.ndarray:
        """
        Get all node coordinates as array.

        Returns:
            Array of shape (13, 3) with 3D coordinates
        """
        return np.array([node.coordinates for node in self.nodes])

    def get_edges_list(self) -> List[Tuple[int, int]]:
        """Get list of edges (0-based indexing)."""
        return sorted(list(self.edges))

    def get_neighbors(self, node_idx: int) -> List[int]:
        """
        Get neighbors of a node.

        Args:
            node_idx: Node index (0-based)

        Returns:
            List of neighbor indices
        """
        return [j for j in range(self.num_nodes) if self.adjacency_matrix[node_idx, j] == 1]

    def visualize_3d(self, show_labels: bool = True, save_path: Optional[str] = None):
        """
        Visualize the Metatron Cube in 3D.

        Args:
            show_labels: Whether to show node labels
            save_path: Optional path to save figure
        """
        try:
            import matplotlib.pyplot as plt
            from mpl_toolkits.mplot3d import Axes3D
        except ImportError:
            print("Matplotlib required for visualization")
            return

        fig = plt.figure(figsize=(12, 10))
        ax = fig.add_subplot(111, projection='3d')

        coords = self.get_node_coordinates()

        # Plot nodes by type
        center_coords = coords[0:1]
        hexagon_coords = coords[1:7]
        cube_coords = coords[7:13]

        ax.scatter(*center_coords.T, c='red', s=300, marker='o', label='Center', alpha=0.9, edgecolors='black', linewidths=2)
        ax.scatter(*hexagon_coords.T, c='blue', s=200, marker='h', label='Hexagon', alpha=0.8, edgecolors='black', linewidths=1.5)
        ax.scatter(*cube_coords.T, c='green', s=200, marker='s', label='Cube', alpha=0.8, edgecolors='black', linewidths=1.5)

        # Plot edges
        for i, j in self.edges:
            point1 = coords[i]
            point2 = coords[j]
            ax.plot([point1[0], point2[0]],
                   [point1[1], point2[1]],
                   [point1[2], point2[2]],
                   'k-', alpha=0.3, linewidth=0.8)

        # Labels
        if show_labels:
            for node in self.nodes:
                ax.text(node.coordinates[0], node.coordinates[1], node.coordinates[2],
                       f'  {node.index+1}', fontsize=8)

        ax.set_xlabel('X', fontsize=10)
        ax.set_ylabel('Y', fontsize=10)
        ax.set_zlabel('Z', fontsize=10)
        ax.set_title('Metatron Cube - 13 Nodes, 78 Edges', fontsize=14, fontweight='bold')
        ax.legend(fontsize=10)

        # Equal aspect ratio
        max_range = 1.5
        ax.set_xlim([-max_range, max_range])
        ax.set_ylim([-max_range, max_range])
        ax.set_zlim([-max_range, max_range])

        if save_path:
            plt.savefig(save_path, dpi=300, bbox_inches='tight')

        return fig

    def to_networkx(self) -> nx.Graph:
        """
        Convert to NetworkX graph for analysis.

        Returns:
            NetworkX Graph object
        """
        G = nx.Graph()

        # Add nodes with attributes
        for node in self.nodes:
            G.add_node(node.index,
                      node_type=node.node_type.value,
                      coordinates=node.coordinates,
                      label=node.label)

        # Add edges
        G.add_edges_from(self.edges)

        return G

    def get_statistics(self) -> Dict:
        """
        Compute graph statistics.

        Returns:
            Dictionary with graph properties
        """
        degrees = np.sum(self.adjacency_matrix, axis=1)

        return {
            'num_nodes': self.num_nodes,
            'num_edges': len(self.edges),
            'min_degree': int(np.min(degrees)),
            'max_degree': int(np.max(degrees)),
            'avg_degree': float(np.mean(degrees)),
            'degree_sequence': degrees.tolist(),
            'is_connected': self._is_connected(),
            'diameter': self._compute_diameter(),
        }

    def _is_connected(self) -> bool:
        """Check if graph is connected using BFS."""
        visited = set([0])
        queue = [0]

        while queue:
            current = queue.pop(0)
            for neighbor in self.get_neighbors(current):
                if neighbor not in visited:
                    visited.add(neighbor)
                    queue.append(neighbor)

        return len(visited) == self.num_nodes

    def _compute_diameter(self) -> int:
        """Compute graph diameter (longest shortest path)."""
        # Floyd-Warshall for all-pairs shortest paths
        dist = np.full((self.num_nodes, self.num_nodes), np.inf)
        np.fill_diagonal(dist, 0)

        for i, j in self.edges:
            dist[i, j] = 1
            dist[j, i] = 1

        for k in range(self.num_nodes):
            for i in range(self.num_nodes):
                for j in range(self.num_nodes):
                    dist[i, j] = min(dist[i, j], dist[i, k] + dist[k, j])

        return int(np.max(dist[np.isfinite(dist)]))

    def print_structure(self):
        """Print detailed structure information."""
        print("\n" + "=" * 70)
        print("METATRON CUBE GRAPH STRUCTURE")
        print("=" * 70)

        print(f"\nNodes: {self.num_nodes}")
        for node in self.nodes:
            print(f"  {node.label}: {node.coordinates}")

        print(f"\nEdges: {len(self.edges)}")
        print(f"  Edge list (first 20): {self.get_edges_list()[:20]}")

        stats = self.get_statistics()
        print(f"\nGraph Statistics:")
        for key, value in stats.items():
            if key != 'degree_sequence':
                print(f"  {key}: {value}")

        laplacian = self.get_laplacian_matrix()
        eigenvalues = np.linalg.eigvalsh(laplacian)
        print(f"\nLaplacian Spectrum (eigenvalues):")
        print(f"  {eigenvalues}")
        print(f"  Algebraic connectivity (λ₂): {eigenvalues[1]:.6f}")

        print("=" * 70 + "\n")


# Demonstration
if __name__ == "__main__":
    print("\nInitializing Metatron Cube Graph...")

    graph = MetatronGraph()
    graph.print_structure()

    print(f"Adjacency Matrix (first 5x5 block):")
    print(graph.get_adjacency_matrix()[:5, :5])

    print("\nMetatron Cube initialized successfully!")
