"""
Quantum State Operator (QSO) - Complete Implementation

This module implements the full Metatron Quantum State Operator as specified in QSO.pdf.

It integrates:
1. 13-dimensional Hilbert space H₁₃
2. Metatron Graph structure (13 nodes, 78 edges)
3. Dynamic Tripolar Logic (DTL)
4. Graph Laplacian operator
5. Metatron-Hamilton operator
6. Symmetry group G_M
7. Spectral decomposition and symmetry orbitals
8. DTL resonator network (Kuramoto model)

The QSO provides a complete framework for:
- Quantum information processing with tripolar advantage
- Graph-based quantum dynamics
- Symmetry-preserving transformations
- Hardware implementation roadmap (photonics, neuromorphic)

Author: Auto-generated from QSO.pdf specification
Date: 2025-11-11
"""

import numpy as np
from typing import List, Tuple, Dict, Optional, Callable
from dataclasses import dataclass
import scipy.linalg as la
from scipy.integrate import odeint

from quantum_state import QuantumState, QuantumUnitaryOperator, METATRON_DIMENSION
from dtl import DTLState, DTLResonator, TripolarState, TripolarInformationTheory
from metatron_graph import MetatronGraph


@dataclass
class QSOParameters:
    """Parameters for the Quantum State Operator."""
    J: float = 1.0  # Coupling constant for Laplacian
    epsilon: np.ndarray = None  # On-site energies (13 values)
    omega: np.ndarray = None  # Resonator frequencies (13 values)
    kappa: float = 1.0  # Resonator coupling strength

    def __post_init__(self):
        if self.epsilon is None:
            self.epsilon = np.zeros(METATRON_DIMENSION)
        if self.omega is None:
            self.omega = np.zeros(METATRON_DIMENSION)


class MetatronHamiltonOperator:
    """
    Metatron-Hamilton Operator (Section 6.2 of QSO.pdf).

    H_MC = -J·L + Σᵢ εᵢ|vᵢ⟩⟨vᵢ|

    Where:
    - L: Graph Laplacian operator
    - J > 0: Hopping/coupling constant
    - εᵢ: On-site energy at node i

    This represents a tight-binding model on the Metatron graph where
    excitations can tunnel between neighboring nodes with coupling J
    and experience local potentials εᵢ.
    """

    def __init__(self, graph: MetatronGraph, params: QSOParameters):
        """
        Initialize Metatron-Hamilton operator.

        Args:
            graph: Metatron graph structure
            params: QSO parameters
        """
        self.graph = graph
        self.params = params

        # Build Laplacian
        self.laplacian = graph.get_laplacian_matrix()

        # Build Hamilton matrix
        self.hamiltonian = self._build_hamiltonian()

        # Spectral decomposition
        self.eigenvalues = None
        self.eigenvectors = None
        self._diagonalize()

    def _build_hamiltonian(self) -> np.ndarray:
        """
        Construct the Hamilton matrix.

        Returns:
            13×13 Hamiltonian matrix
        """
        H = -self.params.J * self.laplacian + np.diag(self.params.epsilon)
        return H

    def _diagonalize(self):
        """Perform spectral decomposition of Hamiltonian."""
        # Use eigh for Hermitian matrices (real symmetric in this case)
        self.eigenvalues, self.eigenvectors = la.eigh(self.hamiltonian)

    def get_ground_state(self) -> QuantumState:
        """
        Get ground state (lowest energy eigenstate).

        Returns:
            Ground state quantum state
        """
        ground_eigenvector = self.eigenvectors[:, 0]
        return QuantumState(ground_eigenvector, normalize=False)

    def get_eigenstate(self, n: int) -> Tuple[float, QuantumState]:
        """
        Get n-th eigenstate.

        Args:
            n: Index of eigenstate (0 = ground state)

        Returns:
            (energy, eigenstate) tuple
        """
        energy = self.eigenvalues[n]
        eigenvector = self.eigenvectors[:, n]
        state = QuantumState(eigenvector, normalize=False)
        return energy, state

    def time_evolution_operator(self, t: float) -> QuantumUnitaryOperator:
        """
        Compute time evolution operator U(t) = exp(-iHt/ℏ).

        For simplicity, we set ℏ = 1.

        Args:
            t: Time

        Returns:
            Unitary time evolution operator
        """
        # U(t) = Σₖ exp(-iEₖt)|φₖ⟩⟨φₖ|
        U = np.zeros((METATRON_DIMENSION, METATRON_DIMENSION), dtype=complex)

        for k in range(METATRON_DIMENSION):
            E_k = self.eigenvalues[k]
            phi_k = self.eigenvectors[:, k]
            # Outer product |φₖ⟩⟨φₖ|
            projector = np.outer(phi_k, phi_k.conj())
            U += np.exp(-1j * E_k * t) * projector

        return QuantumUnitaryOperator(U)

    def evolve_state(self, initial_state: QuantumState, t: float) -> QuantumState:
        """
        Evolve a quantum state in time.

        |ψ(t)⟩ = U(t)|ψ(0)⟩

        Args:
            initial_state: Initial quantum state
            t: Time

        Returns:
            Evolved state
        """
        U_t = self.time_evolution_operator(t)
        return initial_state.apply(U_t)

    def get_spectrum_info(self) -> Dict:
        """
        Get detailed spectral information.

        Returns:
            Dictionary with spectrum details
        """
        return {
            'eigenvalues': self.eigenvalues.tolist(),
            'ground_state_energy': float(self.eigenvalues[0]),
            'energy_gap': float(self.eigenvalues[1] - self.eigenvalues[0]),
            'max_energy': float(self.eigenvalues[-1]),
            'energy_spread': float(self.eigenvalues[-1] - self.eigenvalues[0]),
        }

    def print_spectrum(self):
        """Print spectral information."""
        print("\n" + "=" * 70)
        print("METATRON-HAMILTON OPERATOR - SPECTRAL ANALYSIS")
        print("=" * 70)

        info = self.get_spectrum_info()

        print(f"\nParameters:")
        print(f"  Coupling constant J: {self.params.J}")
        print(f"  On-site energies: {self.params.epsilon[:3]}... (13 values)")

        print(f"\nSpectrum:")
        print(f"  Ground state energy E₀: {info['ground_state_energy']:.6f}")
        print(f"  First excited state E₁: {self.eigenvalues[1]:.6f}")
        print(f"  Energy gap ΔE: {info['energy_gap']:.6f}")
        print(f"  Highest energy E₁₂: {info['max_energy']:.6f}")
        print(f"  Total spread: {info['energy_spread']:.6f}")

        print(f"\nFull Eigenvalue Spectrum:")
        for k, E_k in enumerate(self.eigenvalues):
            print(f"  E_{k}: {E_k:>10.6f}")

        print("=" * 70 + "\n")


class SymmetryGroup:
    """
    Symmetry Group G_M of the Metatron Cube (Section 4).

    The automorphism group contains permutations that preserve the graph structure:
    G_M := Aut(G_MC) = {σ ∈ S₁₃ | P_σ A P_σ^(-1) = A}

    This includes:
    - Hexagonal rotations (C₆)
    - Reflections (D₆)
    - Cube symmetries (S₄)
    """

    def __init__(self, graph: MetatronGraph):
        """
        Initialize symmetry group.

        Args:
            graph: Metatron graph
        """
        self.graph = graph
        self.generators = self._find_generators()
        self.group_elements = self._generate_group()

    def _find_generators(self) -> List[np.ndarray]:
        """
        Find generators of the symmetry group.

        Returns:
            List of permutation matrices (generators)
        """
        generators = []

        # Generator 1: Hexagonal rotation by 60° (C₆)
        # Maps: v2→v3→v4→v5→v6→v7→v2, fixes v1 and cube nodes
        perm_hex_rot = np.arange(METATRON_DIMENSION)
        perm_hex_rot[1:7] = [2, 3, 4, 5, 6, 1]  # Cyclic shift of hexagon nodes (0-indexed: 1-6)
        generators.append(self._permutation_to_matrix(perm_hex_rot))

        # Generator 2: Reflection through v2-v5 axis (reflection symmetry)
        # Maps: v3↔v7, v4↔v6, fixes v1, v2, v5
        perm_reflect = np.arange(METATRON_DIMENSION)
        perm_reflect[[2, 6]] = [6, 2]  # v3 ↔ v7 (indices 2, 6)
        perm_reflect[[3, 5]] = [5, 3]  # v4 ↔ v6 (indices 3, 5)
        generators.append(self._permutation_to_matrix(perm_reflect))

        return generators

    def _permutation_to_matrix(self, perm: np.ndarray) -> np.ndarray:
        """Convert permutation array to permutation matrix."""
        P = np.zeros((METATRON_DIMENSION, METATRON_DIMENSION))
        for i, j in enumerate(perm):
            P[i, j] = 1
        return P

    def _generate_group(self) -> List[np.ndarray]:
        """
        Generate all group elements from generators.

        Returns:
            List of permutation matrices forming the group
        """
        # For simplicity, return generators and identity
        # Full group generation would use Schreier-Sims algorithm
        group = [np.eye(METATRON_DIMENSION)]  # Identity
        group.extend(self.generators)

        # Add some compositions
        for g1 in self.generators:
            for g2 in self.generators:
                group.append(g1 @ g2)

        # Remove duplicates (compare matrices)
        unique_group = []
        for g in group:
            is_unique = True
            for u in unique_group:
                if np.allclose(g, u):
                    is_unique = False
                    break
            if is_unique:
                unique_group.append(g)

        return unique_group

    def get_order(self) -> int:
        """Get order of the symmetry group |G_M|."""
        return len(self.group_elements)

    def is_symmetric_operator(self, operator_matrix: np.ndarray, tol: float = 1e-8) -> bool:
        """
        Check if an operator commutes with all symmetry operations.

        [O, U_σ] = 0 for all σ ∈ G_M

        Args:
            operator_matrix: Operator matrix
            tol: Tolerance

        Returns:
            True if operator is G_M-invariant
        """
        for g in self.group_elements:
            # Check if O commutes with g: gOg^(-1) = O
            transformed = g @ operator_matrix @ g.T
            if not np.allclose(transformed, operator_matrix, atol=tol):
                return False
        return True

    def print_info(self):
        """Print symmetry group information."""
        print("\n" + "=" * 70)
        print("SYMMETRY GROUP G_M")
        print("=" * 70)
        print(f"Order |G_M|: {self.get_order()}")
        print(f"Number of generators: {len(self.generators)}")
        print("=" * 70 + "\n")


class DTLResonatorNetwork:
    """
    DTL Resonator Network on the Metatron Cube (Section 7.2).

    A network of 13 coupled DTL resonators, one per node, with dynamics:

    dφᵢ/dt = ωᵢ + Σⱼ:(vᵢ,vⱼ)∈E κᵢⱼ sin(φⱼ - φᵢ)

    This implements a Kuramoto-like synchronization model on the Metatron graph.
    The topology E determines coupling structure.
    """

    def __init__(self, graph: MetatronGraph, params: QSOParameters):
        """
        Initialize DTL resonator network.

        Args:
            graph: Metatron graph structure
            params: QSO parameters
        """
        self.graph = graph
        self.params = params
        self.num_nodes = graph.num_nodes

        # Initialize resonators
        self.phases = np.random.uniform(0, 2*np.pi, self.num_nodes)

    def derivative(self, phases: np.ndarray, t: float) -> np.ndarray:
        """
        Compute time derivatives dφ/dt for all resonators.

        Args:
            phases: Current phases (length 13)
            t: Current time

        Returns:
            Phase derivatives (length 13)
        """
        dphi = np.copy(self.params.omega)

        # Add coupling terms
        A = self.graph.get_adjacency_matrix()

        for i in range(self.num_nodes):
            coupling_sum = 0.0
            for j in range(self.num_nodes):
                if A[i, j] == 1:  # Nodes are connected
                    coupling_sum += self.params.kappa * np.sin(phases[j] - phases[i])
            dphi[i] += coupling_sum

        return dphi

    def integrate(self, t_span: Tuple[float, float], dt: float = 0.01) -> Tuple[np.ndarray, np.ndarray]:
        """
        Integrate the resonator network dynamics.

        Args:
            t_span: (t_start, t_end)
            dt: Time step

        Returns:
            (times, phases) arrays, phases has shape (num_steps, 13)
        """
        times = np.arange(t_span[0], t_span[1], dt)
        phases = odeint(self.derivative, self.phases, times)
        return times, phases

    def compute_order_parameter(self, phases: np.ndarray) -> float:
        """
        Compute Kuramoto order parameter r.

        r = |⟨exp(iφ)⟩| = |(1/N) Σⱼ exp(iφⱼ)|

        Measures synchronization: r=0 (desynchronized), r=1 (synchronized)

        Args:
            phases: Phase array (can be 1D for single time or 2D for time series)

        Returns:
            Order parameter r ∈ [0, 1]
        """
        if len(phases.shape) == 1:
            # Single time point
            z = np.mean(np.exp(1j * phases))
            return np.abs(z)
        else:
            # Time series
            z = np.mean(np.exp(1j * phases), axis=1)
            return np.abs(z)

    def phases_to_dtl_states(self, phases: np.ndarray) -> List[float]:
        """
        Convert phases to DTL-like values in [0, 1].

        x_i = (1 + cos(φ_i)) / 2

        Args:
            phases: Phase values (length 13)

        Returns:
            DTL state values (length 13)
        """
        return [(1.0 + np.cos(phi)) / 2.0 for phi in phases]

    def get_synchronization_threshold(self) -> float:
        """
        Estimate critical coupling κ_c for synchronization.

        κ_c ≈ 2|ω_max| / λ₂

        where λ₂ is algebraic connectivity (2nd eigenvalue of Laplacian).

        Returns:
            Critical coupling strength
        """
        laplacian = self.graph.get_laplacian_matrix()
        eigenvalues = np.linalg.eigvalsh(laplacian)
        lambda_2 = eigenvalues[1]  # Algebraic connectivity

        omega_max = np.max(np.abs(self.params.omega))
        kappa_c = 2 * omega_max / lambda_2 if lambda_2 > 0 else np.inf

        return kappa_c


class QuantumStateOperator:
    """
    Complete Quantum State Operator (QSO) - Main class.

    Integrates all components:
    - Quantum state representation (H₁₃)
    - Metatron graph structure
    - Hamilton operator and dynamics
    - DTL resonator network
    - Symmetry group operations
    """

    def __init__(self, params: Optional[QSOParameters] = None):
        """
        Initialize complete QSO.

        Args:
            params: Optional parameters (uses defaults if None)
        """
        if params is None:
            params = QSOParameters()

        self.params = params

        # Initialize components
        print("Initializing Metatron Cube Graph...")
        self.graph = MetatronGraph()

        print("Building Hamilton Operator...")
        self.hamiltonian = MetatronHamiltonOperator(self.graph, params)

        print("Analyzing Symmetry Group...")
        self.symmetry = SymmetryGroup(self.graph)

        print("Setting up DTL Resonator Network...")
        self.resonator_network = DTLResonatorNetwork(self.graph, params)

        print("QSO Initialization Complete!\n")

    def create_quantum_state(self, amplitudes: np.ndarray, normalize: bool = True) -> QuantumState:
        """Create quantum state from amplitudes."""
        return QuantumState(amplitudes, normalize=normalize)

    def get_basis_state(self, node: int) -> QuantumState:
        """Get basis state |node⟩."""
        return QuantumState.basis_state(node)

    def get_ground_state(self) -> QuantumState:
        """Get Hamiltonian ground state."""
        return self.hamiltonian.get_ground_state()

    def evolve_quantum_state(self, initial_state: QuantumState, time: float) -> QuantumState:
        """Evolve quantum state in time."""
        return self.hamiltonian.evolve_state(initial_state, time)

    def simulate_resonator_dynamics(self, t_span: Tuple[float, float], dt: float = 0.01) -> Tuple[np.ndarray, np.ndarray]:
        """Simulate DTL resonator network."""
        return self.resonator_network.integrate(t_span, dt)

    def quantum_to_dtl_correspondence(self, quantum_state: QuantumState) -> List[float]:
        """
        Map quantum state to DTL values (Section 7.3).

        Amplitude → DTL value: xᵢ = |αᵢ|²
        Phase → Resonator phase: φᵢ = arg(αᵢ)

        Args:
            quantum_state: Quantum state

        Returns:
            DTL values (probabilities) for each node
        """
        return quantum_state.probabilities().tolist()

    def analyze_symmetry_orbitals(self) -> Dict:
        """
        Analyze eigenstates by symmetry classification (Section 6.4).

        Returns:
            Dictionary with symmetry-classified eigenstates
        """
        orbitals = {}

        for k in range(METATRON_DIMENSION):
            energy, eigenstate = self.hamiltonian.get_eigenstate(k)
            orbitals[f"orbital_{k}"] = {
                'energy': float(energy),
                'eigenstate': eigenstate.amplitudes.tolist(),
                'symmetry_class': 'unclassified'  # Would require group representation theory
            }

        return orbitals

    def print_full_analysis(self):
        """Print comprehensive QSO analysis."""
        print("\n" + "=" * 70)
        print("QUANTUM STATE OPERATOR (QSO) - COMPLETE ANALYSIS")
        print("=" * 70 + "\n")

        # Graph structure
        print("METATRON GRAPH")
        print("-" * 70)
        stats = self.graph.get_statistics()
        for key, val in stats.items():
            if key != 'degree_sequence':
                print(f"  {key}: {val}")

        # Hamiltonian spectrum
        self.hamiltonian.print_spectrum()

        # Symmetry
        self.symmetry.print_info()

        # DTL capacity
        print("\nDTL INFORMATION CAPACITY")
        print("-" * 70)
        TripolarInformationTheory.print_capacity_analysis()

        # Resonator synchronization
        print("\nRSONATOR NETWORK")
        print("-" * 70)
        kappa_c = self.resonator_network.get_synchronization_threshold()
        print(f"Critical coupling κ_c: {kappa_c:.6f}")
        print(f"Current coupling κ: {self.params.kappa:.6f}")
        print(f"Synchronization regime: {'Yes' if self.params.kappa > kappa_c else 'No'}")

        print("\n" + "=" * 70)
        print("END OF QSO ANALYSIS")
        print("=" * 70 + "\n")


# Demonstration
if __name__ == "__main__":
    print("\n" + "=" * 70)
    print("QUANTUM STATE OPERATOR (QSO) - DEMONSTRATION")
    print("=" * 70 + "\n")

    # Create QSO with default parameters
    qso = QuantumStateOperator()

    # Full analysis
    qso.print_full_analysis()

    # Create and evolve a quantum state
    print("\nQUANTUM DYNAMICS EXAMPLE")
    print("-" * 70)
    initial_state = qso.get_basis_state(0)  # Start at center node
    print(f"Initial state: |v1⟩ (center node)")
    print(f"Initial probabilities: {initial_state.probabilities()[:5]}...")

    evolved_state = qso.evolve_quantum_state(initial_state, time=1.0)
    print(f"\nEvolved state at t=1.0:")
    print(f"Probabilities: {evolved_state.probabilities()[:5]}...")

    # DTL correspondence
    dtl_values = qso.quantum_to_dtl_correspondence(evolved_state)
    print(f"\nDTL correspondence: {dtl_values[:5]}...")

    print("\n" + "=" * 70)
    print("QSO DEMONSTRATION COMPLETE")
    print("=" * 70 + "\n")
