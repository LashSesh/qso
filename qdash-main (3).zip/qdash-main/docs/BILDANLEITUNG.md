# 🖼️ Q⊗DASH Bildanleitung - Schritt für Schritt

## 🎯 Übersicht: Der komplette Weg

```
┌─────────────┐
│   Start     │
│  (Du bist   │
│    hier)    │
└──────┬──────┘
       │
       ▼
┌─────────────────────────────────────────┐
│  Schritt 1: DOWNLOAD                    │
│  🌐 GitHub → ZIP herunterladen          │
│  ⏱️ 2-5 Minuten                          │
└──────┬──────────────────────────────────┘
       │
       ▼
┌─────────────────────────────────────────┐
│  Schritt 2: ENTPACKEN                   │
│  📦 ZIP → Desktop\qdash                  │
│  ⏱️ 1-2 Minuten                          │
└──────┬──────────────────────────────────┘
       │
       ▼
┌─────────────────────────────────────────┐
│  Schritt 3: RUST INSTALLIEREN           │
│  🦀 rustup.rs → Installation             │
│  ⏱️ 5-10 Minuten                         │
└──────┬──────────────────────────────────┘
       │
       ▼
┌─────────────────────────────────────────┐
│  Schritt 4: BUILD TOOLS                 │
│  🔧 Visual Studio C++ Tools              │
│  ⏱️ 30-40 Minuten (LANGE!)              │
└──────┬──────────────────────────────────┘
       │
       ▼
┌─────────────────────────────────────────┐
│  Schritt 5: PROJEKT BAUEN               │
│  ⚙️ cargo build --release               │
│  ⏱️ 15-20 Minuten                        │
└──────┬──────────────────────────────────┘
       │
       ▼
┌─────────────────────────────────────────┐
│  Schritt 6: SERVER STARTEN              │
│  🚀 cargo run (Start-Script)             │
│  ⏱️ 30 Sekunden                          │
└──────┬──────────────────────────────────┘
       │
       ▼
┌─────────────────────────────────────────┐
│  Schritt 7: BROWSER ÖFFNEN              │
│  🌐 localhost:8080                       │
│  ⏱️ 5 Sekunden                           │
└──────┬──────────────────────────────────┘
       │
       ▼
┌─────────────┐
│  🎉 FERTIG! │
│  Dashboard  │
│    läuft    │
└─────────────┘
```

---

## 📸 Schritt 1: Download von GitHub

### Was du siehst in deinem Browser:

```
┌────────────────────────────────────────────────────────────┐
│  🦊 GitHub - LashSesh/qdash                          [X]   │
├────────────────────────────────────────────────────────────┤
│  ← → ⟳  🔒 github.com/LashSesh/qdash                      │
├────────────────────────────────────────────────────────────┤
│                                                             │
│  LashSesh / qdash                                          │
│                                                             │
│  📁 Code    ⚠️ Issues    🔀 Pull requests                  │
│                                                             │
│  ┌──────────────────────────────────────┐                 │
│  │  < > Code ▼                          │  ← HIER KLICKEN│
│  │                                       │                 │
│  │  Clone HTTPS  📋                     │                 │
│  │  ┌────────────────────────────────┐  │                 │
│  │  │ https://github.com/...         │  │                 │
│  │  └────────────────────────────────┘  │                 │
│  │                                       │                 │
│  │  Open with GitHub Desktop            │                 │
│  │                                       │                 │
│  │  📥 Download ZIP                     │  ← DANN HIER   │
│  │     ^^^^^^^^^^^^^^^                   │     KLICKEN!   │
│  └───────────────────────────────────────┘                 │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

### Was passiert danach:

```
Browser-Fenster unten:
┌────────────────────────────────────────────────────────────┐
│  ↓ qdash-main.zip    50 MB    [=====>      ] 50%          │
└────────────────────────────────────────────────────────────┘
                      ⏱️ Warte, bis 100% erreicht sind!
```

---

## 📸 Schritt 2: Entpacken

### Im Downloads-Ordner:

```
┌────────────────────────────────────────────────────────────┐
│  📁 Downloads                                        [X]   │
├────────────────────────────────────────────────────────────┤
│  🔍 Suchen...                                              │
├────────────────────────────────────────────────────────────┤
│                                                             │
│  Name                        Änderungsdatum    Typ         │
│  ──────────────────────────────────────────────────────── │
│  📦 qdash-main.zip           Heute, 10:30    ZIP-Ordner   │
│     ^^^^^^^^^^^^^^^                                        │
│     RECHTSKLICK HIER!                                      │
│                                                             │
│                                                             │
└─────────────────────────────────────────────────────────────┘

Rechtsklick-Menü:
┌──────────────────────────┐
│  Öffnen                  │
│  Öffnen mit...           │
│  ──────────────────      │
│  📦 Alle extrahieren...  │  ← KLICK HIER
│  Mit 7-Zip extrahieren   │
│  ──────────────────      │
│  Löschen                 │
│  Umbenennen              │
│  Eigenschaften           │
└──────────────────────────┘
```

### Extrahieren-Dialog:

```
┌────────────────────────────────────────────────────────────┐
│  ZIP-komprimierter Ordner extrahieren             [X]     │
├────────────────────────────────────────────────────────────┤
│                                                             │
│  Dateien werden in diesen Ordner extrahiert:               │
│                                                             │
│  ┌────────────────────────────────────────────┐  [...]    │
│  │ C:\Users\DEINNAME\Desktop\qdash            │           │
│  └────────────────────────────────────────────┘           │
│           ^^^^^^^^^^^^^^^^^^^^^^^^^                        │
│           ÄNDERE HIER DEN PFAD!                            │
│                                                             │
│  ☑️ Extrahierte Dateien anzeigen                           │
│                                                             │
│  [ Abbrechen ]         [ Extrahieren ]  ← KLICK           │
│                          ^^^^^^^^^^^^                      │
└─────────────────────────────────────────────────────────────┘
```

---

## 📸 Schritt 3: Rust Installation

### Rust Download-Seite:

```
┌────────────────────────────────────────────────────────────┐
│  🦀 Rust Programming Language                       [X]   │
├────────────────────────────────────────────────────────────┤
│  🔒 rustup.rs                                              │
├────────────────────────────────────────────────────────────┤
│                                                             │
│            🦀 RUST                                         │
│                                                             │
│        Get started with Rust                               │
│                                                             │
│  ┌────────────────────────────────────────────────────┐   │
│  │                                                     │   │
│  │     📥 rustup-init.exe (64-bit)                    │   │
│  │        ^^^^^^^^^^^^^^^^^^^^^^^^^                    │   │
│  │        KLICK HIER ZUM DOWNLOAD!                     │   │
│  │                                                     │   │
│  └────────────────────────────────────────────────────┘   │
│                                                             │
│  For Windows, download and run rustup-init.exe             │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

### Rust Installation - Kommandozeile:

```
┌────────────────────────────────────────────────────────────┐
│  C:\Users\DEINNAME\rustup-init.exe                  [-][X]│
├────────────────────────────────────────────────────────────┤
│                                                             │
│  Welcome to Rust!                                          │
│                                                             │
│  This will download and install the official compiler      │
│  for the Rust programming language, and its package        │
│  manager, Cargo.                                           │
│                                                             │
│  Current installation options:                             │
│                                                             │
│     default host triple: x86_64-pc-windows-msvc            │
│     default toolchain: stable                              │
│     modify PATH variable: yes                              │
│                                                             │
│  1) Proceed with installation (default)   ← WIR WOLLEN DAS│
│  2) Customize installation                                 │
│  3) Cancel installation                                    │
│                                                             │
│  > _                                                        │
│    ^                                                        │
│    DRÜCKE EINFACH ENTER!                                   │
│                                                             │
└─────────────────────────────────────────────────────────────┘

Nach Enter:
┌────────────────────────────────────────────────────────────┐
│  Downloading rustc                   [========>    ] 65%   │
│  Downloading cargo                   [====>       ] 40%   │
│  Downloading rust-std                [===========>] 95%   │
│                                                             │
│  ⏱️ Warte geduldig...                                      │
└─────────────────────────────────────────────────────────────┘

Wenn fertig:
┌────────────────────────────────────────────────────────────┐
│  Rust is installed now. Great!                             │
│                                                             │
│  To get started you may need to restart your current       │
│  shell.                                                    │
│                                                             │
│  Press Enter to continue...                                │
└─────────────────────────────────────────────────────────────┘
```

---

## 📸 Schritt 4: Visual Studio Build Tools

### Download-Seite:

```
┌────────────────────────────────────────────────────────────┐
│  Visual Studio Downloads                            [X]   │
├────────────────────────────────────────────────────────────┤
│                                                             │
│  Visual Studio 2022                                        │
│  ┌──────────────────────┐                                 │
│  │  Community ⬇️        │                                 │
│  │  Professional ⬇️     │                                 │
│  │  Enterprise ⬇️       │                                 │
│  └──────────────────────┘                                 │
│                                                             │
│  Tools für Visual Studio 2022                              │
│  ┌────────────────────────────────────────────┐           │
│  │  📥 Build Tools für Visual Studio 2022    │  ← KLICK  │
│  │     ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^      │           │
│  └────────────────────────────────────────────┘           │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

### Installer - Workload-Auswahl:

```
┌────────────────────────────────────────────────────────────┐
│  Visual Studio Installer                            [X]   │
├────────────────────────────────────────────────────────────┤
│  Workloads  │ Einzelne Komponenten │ Sprachpakete         │
├────────────────────────────────────────────────────────────┤
│                                                             │
│  Wählen Sie die Workloads aus:                             │
│                                                             │
│  ┌────────────────────┐  ┌────────────────────┐           │
│  │ ☑️ Desktop-        │  │ ☐ .NET Desktop-   │           │
│  │    Entwicklung     │  │    Entwicklung     │           │
│  │    mit C++         │  │                    │           │
│  │    ^^^^^^^         │  └────────────────────┘           │
│  │    ANKLICKEN!      │                                    │
│  └────────────────────┘  ┌────────────────────┐           │
│                          │ ☐ Web-             │           │
│  ┌────────────────────┐  │    Entwicklung     │           │
│  │ ☐ Linux-           │  │                    │           │
│  │    Entwicklung     │  └────────────────────┘           │
│  │    mit C++         │                                    │
│  └────────────────────┘                                    │
│                                                             │
│  Installationsdetails:                                     │
│  • MSVC v143                                               │
│  • Windows 10 SDK                                          │
│  • C++ CMake Tools                                         │
│  Installationsgröße: 6.2 GB                                │
│                                                             │
│  [ Abbrechen ]              [ Installieren ]  ← KLICK     │
│                               ^^^^^^^^^^^^^                │
└─────────────────────────────────────────────────────────────┘

Während Installation:
┌────────────────────────────────────────────────────────────┐
│  Visual Studio wird installiert...                         │
│                                                             │
│  [===========================>            ] 65%            │
│                                                             │
│  Heruntergeladen: 4.1 GB / 6.2 GB                          │
│  Verbleibende Zeit: ca. 15 Minuten                         │
│                                                             │
│  ⏱️ Jetzt ist eine gute Zeit für eine Pause! ☕           │
└─────────────────────────────────────────────────────────────┘
```

---

## 📸 Schritt 5: Projekt bauen

### Kommandozeile öffnen:

```
Datei-Explorer:
┌────────────────────────────────────────────────────────────┐
│  📁 qdash                                           [X]   │
├────────────────────────────────────────────────────────────┤
│  ← → ↑  ⊙ Desktop > qdash                      🔍         │
│         ^^^^^^^^^^                                         │
│         KLICK HIER IN DIE ADRESSLEISTE!                    │
├────────────────────────────────────────────────────────────┤
│                                                             │
│  📁 docs                                                   │
│  📁 metatron-qso-rs                                        │
│  📁 metatron_backend                                       │
│  📁 metatron_dionice_bridge                                │
│  📁 metatron_telemetry                                     │
│  📄 Cargo.toml                                             │
│  📄 start_dashboard.bat                                    │
│                                                             │
└─────────────────────────────────────────────────────────────┘

Dann tippe "cmd":
┌────────────────────────────────────────────────────────────┐
│  📁 qdash                                           [X]   │
├────────────────────────────────────────────────────────────┤
│  ⊙ cmd                                             🔍     │
│    ^^^                                                     │
│    TIPPE "cmd" UND DRÜCKE ENTER                            │
└─────────────────────────────────────────────────────────────┘
```

### Build-Prozess:

```
┌────────────────────────────────────────────────────────────┐
│  Eingabeaufforderung                            [-][☐][X] │
├────────────────────────────────────────────────────────────┤
│  C:\Users\DEINNAME\Desktop\qdash>                          │
│                                                             │
│  C:\...\qdash> cargo build --workspace --release           │
│                ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^              │
│                TIPPE DIESEN BEFEHL                         │
│                                                             │
│     Updating crates.io index                               │
│   Downloaded serde v1.0.228                                │
│   Downloaded tokio v1.35.0                                 │
│   Downloaded nalgebra v0.33.2                              │
│   ... (viele weitere Pakete)                               │
│                                                             │
│    Compiling libc v0.2.177                                 │
│    Compiling serde v1.0.228                                │
│    Compiling num-complex v0.4.6                            │
│    Compiling metatron-qso-rs v0.1.0                        │
│    ... (viele Kompilierungen)                              │
│                                                             │
│  [========================================>      ] 85%     │
│                                                             │
│  ⏱️ Das dauert 15-20 Minuten!                              │
│  ☕ Zeit für einen Kaffee...                               │
│                                                             │
└─────────────────────────────────────────────────────────────┘

Wenn fertig:
┌────────────────────────────────────────────────────────────┐
│     Finished release [optimized] target(s) in 17m 43s      │
│                                                             │
│  ✅ GESCHAFFT! Projekt ist gebaut!                         │
│                                                             │
│  C:\...\qdash> _                                           │
└─────────────────────────────────────────────────────────────┘
```

---

## 📸 Schritt 6 & 7: Server starten & Dashboard öffnen

### Start-Script doppelklicken:

```
Im Datei-Explorer:
┌────────────────────────────────────────────────────────────┐
│  📁 qdash                                           [X]   │
├────────────────────────────────────────────────────────────┤
│  📁 docs                                                   │
│  📁 metatron_backend                                       │
│  📄 Cargo.toml                                             │
│  📄 start_dashboard.bat      ← DOPPELKLICK HIER!         │
│     ^^^^^^^^^^^^^^^^^^^                                    │
│                                                             │
└─────────────────────────────────────────────────────────────┘

Das Script öffnet sich:
┌────────────────────────────────────────────────────────────┐
│  start_dashboard.bat                            [-][☐][X] │
├────────────────────────────────────────────────────────────┤
│   ██████╗ ⊗ ██████╗  █████╗ ███████╗██╗  ██╗              │
│  ██╔═══██╗  ██╔══██╗██╔══██╗██╔════╝██║  ██║              │
│  ██║   ██║  ██║  ██║███████║███████╗███████║              │
│  ██║▄▄ ██║  ██║  ██║██╔══██║╚════██║██╔══██║              │
│   ╚██████╔╝  ██████╔╝██║  ██║███████║██║  ██║              │
│    ╚══▀▀═╝   ╚═════╝ ╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝              │
│                                                             │
│  ========================================                   │
│   Q⊗DASH Dashboard Starter                                │
│  ========================================                   │
│                                                             │
│  ✅ Rust gefunden: cargo 1.75.0                            │
│  ✅ Richtiger Ordner gefunden                              │
│                                                             │
│  ⚠️ ERSTE VERWENDUNG?                                      │
│  Projekt jetzt bauen? (j/n): n                             │
│                                                             │
│  🚀 Starte Q⊗DASH Dashboard Server...                     │
│                                                             │
│  ⚠️ WICHTIG:                                               │
│  - Dieses Fenster NICHT schließen!                         │
│  - Das Dashboard öffnet sich gleich im Browser             │
│                                                             │
│    Compiling metatron_telemetry...                         │
│     Finished release target(s) in 2.1s                     │
│      Running metatron_telemetry                            │
│                                                             │
│  INFO Starting Q⊗DASH Telemetry Server                     │
│  INFO Listening on http://0.0.0.0:8080                     │
│       ^^^^^^^^^^^^^^^^^^^^^^^^^^^^                         │
│       SERVER LÄUFT!                                        │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

### Browser öffnet sich automatisch:

```
┌────────────────────────────────────────────────────────────┐
│  Q⊗DASH - Metatron VM                              [X]   │
├────────────────────────────────────────────────────────────┤
│  ← → ⟳  🔒 localhost:8080                      ⭐ 👤      │
├────────────────────────────────────────────────────────────┤
│  ┌──────────────────────────────────────────────────────┐ │
│  │        Q⊗DASH - Metatron VM                          │ │
│  │  Quantum-Hybrid Calibration System                   │ │
│  └──────────────────────────────────────────────────────┘ │
│                                                             │
│  ┌─────────────────────┬──────────────────────────────┐   │
│  │ System Status       │ Recent Jobs                  │   │
│  │                     │                              │   │
│  │ Algorithm: VQE      │ [Noch keine Jobs]           │   │
│  │ Mode: Explore       │                              │   │
│  │ ψ: 0.8500           │                              │   │
│  │ ρ: 0.9000           │                              │   │
│  │ ω: 0.7500           │                              │   │
│  │                     │                              │   │
│  │ Backend Health:     │                              │   │
│  │ ● SCS               │                              │   │
│  │ ● dioniceOS         │                              │   │
│  │ ● Q⊗DASH            │                              │   │
│  │                     │                              │   │
│  │ Quantum Backend:    │                              │   │
│  │ ┌──────────────┐    │                              │   │
│  │ │ SIMULATOR    │    │                              │   │
│  │ │ local_sim    │    │                              │   │
│  │ └──────────────┘    │                              │   │
│  │ 13 qubits           │                              │   │
│  ├─────────────────────┼──────────────────────────────┤   │
│  │ Metrics History     │ Control Actions              │   │
│  │                     │                              │   │
│  │ [Diagramm mit 3     │ ┌──────────────────────┐    │   │
│  │  bunten Linien]     │ │ ▶ Start Calibration │    │   │
│  │                     │ └──────────────────────┘    │   │
│  │                     │                              │   │
│  │                     │ ┌──────────────────────┐    │   │
│  │                     │ │ 🔄 Refresh All      │    │   │
│  │                     │ └──────────────────────┘    │   │
│  └─────────────────────┴──────────────────────────────┘   │
│                                                             │
└─────────────────────────────────────────────────────────────┘

🎉 ES FUNKTIONIERT! DU HAST ES GESCHAFFT! 🎉
```

---

## 🎮 Was du als nächstes tun kannst

### 1. Starte eine Kalibrierung:

```
Klicke auf [▶ Start Calibration]
     │
     ▼
┌─────────────────────────────────────┐
│ ✓ Calibration job started          │
│   Job ID: abc12345                  │
└─────────────────────────────────────┘
     │
     ▼
Im "Recent Jobs" Bereich erscheint:
┌─────────────────────────────────────┐
│ abc12345... (calibration)           │
│ [RUNNING]                           │
│                                      │
│ Started: 10:30:15                   │
└─────────────────────────────────────┘
```

### 2. Beobachte das Diagramm:

```
Metrics History:

     1.0 ┤        ╭───╮
         │      ╭─╯   ╰─╮        Grün  = ψ (Quality)
     0.8 ┤    ╭─╯       ╰─╮      Blau  = ρ (Stability)
         │  ╭─╯           ╰─╮    Orange = ω (Efficiency)
     0.6 ┤╭─╯               ╰─╮
         │                    ╰─
     0.4 ┴─────────────────────────►
         0s  10s  20s  30s  40s  50s

Die Linien aktualisieren sich automatisch alle 5 Sekunden!
```

---

## 🛑 Zum Beenden

### Server stoppen:

```
Gehe zum schwarzen Fenster:
┌────────────────────────────────────────────────────────────┐
│  start_dashboard.bat                            [-][☐][X] │
├────────────────────────────────────────────────────────────┤
│  INFO Listening on http://0.0.0.0:8080                     │
│  INFO Request: GET /api/status                             │
│  INFO Request: GET /api/jobs                               │
│  ...                                                        │
│                                                             │
│  Drücke: Strg + C                                          │
│          ^^^^^^^^                                           │
│          (Beide Tasten gleichzeitig)                       │
│                                                             │
└─────────────────────────────────────────────────────────────┘

Nach Strg+C:
┌────────────────────────────────────────────────────────────┐
│  ^C                                                        │
│  ========================================                   │
│   Server wurde beendet.                                    │
│  ========================================                   │
│                                                             │
│  Drücken Sie eine beliebige Taste...                       │
└─────────────────────────────────────────────────────────────┘

Fenster schließt sich nach Tastendruck.
```

---

## ✅ Checkliste zum Abhaken

Drucke diese Seite aus und hake ab, was du erledigt hast:

```
┌────────────────────────────────────────────────────┐
│  □  GitHub-Seite geöffnet                          │
│  □  ZIP heruntergeladen                            │
│  □  ZIP entpackt auf Desktop                       │
│  □  Ordner "qdash" auf Desktop sichtbar            │
│  ────────────────────────────────────────────      │
│  □  Rust von rustup.rs heruntergeladen             │
│  □  Rust installiert (rustup-init.exe)             │
│  □  Rust funktioniert (rustc --version)            │
│  ────────────────────────────────────────────      │
│  □  Visual Studio Build Tools heruntergeladen      │
│  □  "Desktop-Entwicklung mit C++" ausgewählt       │
│  □  Build Tools installiert (30-40 Min gewartet)   │
│  ────────────────────────────────────────────      │
│  □  Kommandozeile im qdash-Ordner geöffnet         │
│  □  cargo build --workspace --release ausgeführt   │
│  □  Build abgeschlossen (15-20 Min gewartet)       │
│  ────────────────────────────────────────────      │
│  □  start_dashboard.bat doppelgeklickt             │
│  □  Server gestartet                               │
│  □  Browser öffnet localhost:8080                  │
│  □  Dashboard wird angezeigt                       │
│  ────────────────────────────────────────────      │
│  □  "Start Calibration" Button geklickt            │
│  □  Job erscheint in "Recent Jobs"                 │
│  □  Diagramm aktualisiert sich                     │
│  ────────────────────────────────────────────      │
│  ✅  FERTIG! Ich bin Q⊗DASH Profi! 🎉            │
└────────────────────────────────────────────────────┘
```

---

## 🎨 Farbcodes im Dashboard

```
Farbe               Bedeutung               Wo zu finden
────────────────────────────────────────────────────────
🟢 Grün            Gesund/Gut              Health-Punkte ●
                   ψ (Quality)             Diagramm-Linie

🔵 Blau            ρ (Stability)           Diagramm-Linie
                   Running Status          Job-Status

🟠 Orange          ω (Efficiency)          Diagramm-Linie
                   Pending Status          Job-Status

🟢 Grün hell       Completed              Job-Status

🔴 Rot             Unhealthy              Health-Punkte ●
                   Failed Status           Job-Status

⚫ Grau            Simulator               Backend-Badge
```

---

## 🎓 Du hast es geschafft!

```
        🎉🎉🎉🎉🎉🎉🎉🎉🎉
       🎉              🎉
      🎉  GRATULATION!  🎉
     🎉                  🎉
    🎉   Q⊗DASH LÄUFT!   🎉
   🎉                      🎉
  🎉   Du bist der Beste!  🎉
 🎉                          🎉
🎉🎉🎉🎉🎉🎉🎉🎉🎉🎉🎉🎉🎉🎉🎉
```

**Jetzt kannst du:**
- Mit Quantencomputern experimentieren (simuliert)
- Die Kalibrierung beobachten
- Metriken in Echtzeit sehen
- Dich wie ein echter Quantum-Programmierer fühlen! 🚀

**Viel Spaß mit Q⊗DASH!** ✨
