//! API endpoints

mod handlers;
mod routes;

pub use routes::create_router;
