//! Sequential pipeline processing

/// Sequential pipeline (placeholder)
pub struct SequentialPipeline;

impl SequentialPipeline {
    pub fn new() -> Self {
        Self
    }
}

impl Default for SequentialPipeline {
    fn default() -> Self {
        Self::new()
    }
}
